@echo off
setlocal
cd /d "%~dp0"
echo.
echo ========================================
echo             WORDLESS 1.0.4 BUILD
echo ========================================
echo.
where py >nul 2>nul
if errorlevel 1 goto no_python

echo Step 1 of 2: Check build dependencies
py check_dependencies.py
if errorlevel 1 goto failed

echo.
echo Step 2 of 2: Build standalone Windows executable
echo Existing Python packages will not be reinstalled unless missing or incompatible.
echo PyInstaller's build cache is cleaned to avoid stale packaged resources.
py -m PyInstaller --noconfirm --clean --onefile --windowed --name Wordless --collect-all pymupdf offline_word_processor_immersive.py
if errorlevel 1 goto failed

echo.
echo ========================================
echo Build complete:
echo %~dp0dist\Wordless.exe
echo ========================================
echo.
pause
exit /b 0

:no_python
echo ERROR: Python's Windows launcher (py) was not found.
echo Install Python 3.10 or newer and enable the Python launcher, then retry.
goto failed

:failed
echo.
echo Build failed. Review the error above before retrying.
pause
exit /b 1
