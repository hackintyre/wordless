"""Check build requirements and install only missing or incompatible packages."""
from __future__ import annotations

import importlib.metadata
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIREMENTS = ROOT / "requirements.txt"

try:
    from pip._vendor.packaging.requirements import Requirement
except Exception:
    print("ERROR: pip's packaging helper is unavailable. Please repair/update pip, then retry.")
    raise SystemExit(1)


def normalized_name(name: str) -> str:
    return name.lower().replace("_", "-").replace(".", "-")


def main() -> int:
    requirements = []
    for raw in REQUIREMENTS.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        try:
            requirements.append(Requirement(line))
        except Exception as exc:
            print(f"ERROR: Cannot parse requirement {line!r}: {exc}")
            return 1

    needs_install = []
    print("Checking Wordless build dependencies...\n")
    for req in requirements:
        if req.marker and not req.marker.evaluate():
            print(f"[SKIP] {req}: not required on this platform")
            continue
        try:
            installed = importlib.metadata.version(req.name)
            if req.specifier.contains(installed, prereleases=True):
                print(f"[OK]   {req.name} {installed} already satisfies {req.specifier or 'any version'}")
                continue
            print(f"[FIX]  {req.name} {installed} does not satisfy {req.specifier}; updating this package")
        except importlib.metadata.PackageNotFoundError:
            print(f"[ADD]  {req.name} is not installed")
        needs_install.append(str(req))

    if not needs_install:
        print("\nAll required dependencies are already installed at compatible versions. Nothing to install.")
        return 0

    print("\nInstalling only missing/outdated requirements:")
    for req in needs_install:
        print(f"  - {req}")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", *needs_install],
        cwd=str(ROOT),
        check=False,
    )
    if result.returncode:
        print("\nERROR: Dependency installation failed. Review the pip output above.")
        return result.returncode

    # Verify the requirements after installation so a failed or conflicting
    # environment is caught before PyInstaller starts.
    print("\nVerifying installed versions...")
    failed = []
    for req in requirements:
        if req.marker and not req.marker.evaluate():
            continue
        try:
            installed = importlib.metadata.version(req.name)
            if not req.specifier.contains(installed, prereleases=True):
                failed.append(f"{req.name} {installed} (requires {req.specifier})")
        except importlib.metadata.PackageNotFoundError:
            failed.append(f"{req.name} is missing")
    if failed:
        print("ERROR: Some dependencies still do not meet requirements:")
        for item in failed:
            print(f"  - {item}")
        return 1
    print("All build dependencies are ready.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
