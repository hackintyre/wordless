"""
Wordless: Immersive Word Processor
Local-only word processor with animated seasonal / galaxy / fantasy edge scenery.
Animations are drawn only in side gutters, never over the document editor.
"""
import os, re, json, tempfile, subprocess, sys, shutil, webbrowser, random, math
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, font as tkfont

try:
    from docx import Document
    from docx.shared import Inches, Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

PDF_IMPORT_ERROR = None
try:
    # PyMuPDF is bundled with its package data by build_windows.bat.
    # A broad exception guard prevents a packaging/resource problem in the PDF
    # stack from preventing the entire Wordless editor from starting.
    import pymupdf as fitz  # PyMuPDF, used only for read-only PDF viewing
    from PIL import Image, ImageTk, ImageEnhance, ImageOps
    PDF_OK = True
except Exception as exc:
    fitz = Image = ImageTk = ImageEnhance = ImageOps = None
    PDF_OK = False
    PDF_IMPORT_ERROR = exc

APP = "Wordless 1.0.6"
APP_VERSION = "1.0.6"
AUTOSAVE_MS = 30000

THEMES = {
    "Autumn": {
        "bg": "#171b20", "surface": "#222831", "paper": "#fffaf0", "ink": "#2d2925",
        "chrome": "#392d27", "accent": "#d97736", "muted": "#b8a18e",
        "gutter": "#251d1a", "particles": ["#d97736", "#efaa45", "#a84627", "#d6bd76", "#7e8b42"],
        "kind": "leaf"
    },
    "Galaxy": {
        "bg": "#090d20", "surface": "#121a35", "paper": "#11182d", "ink": "#e8edff",
        "chrome": "#11162b", "accent": "#8b7cff", "muted": "#a5b4dc",
        "gutter": "#080c1d", "particles": ["#ffffff"], "kind": "star"
    },
    "Enchanted Forest": {
        "bg": "#0d1c1b", "surface": "#152c27", "paper": "#10231e", "ink": "#e5f6df",
        "chrome": "#153229", "accent": "#7bd88f", "muted": "#a4c9ad",
        "gutter": "#0a1715", "particles": ["#c7ff8b", "#7fffd4", "#ffe88a", "#9cf4ff", "#d9ffb5"], "kind": "firefly"
    },
    "Snowy": {
        "bg": "#e9edf2", "surface": "#f7f8fa", "paper": "#ffffff", "ink": "#1f2937",
        "chrome": "#243447", "accent": "#3676c8", "muted": "#8a9bb0",
        "gutter": "#dce2e9", "particles": ["#ffffff"], "kind": "snow"
    },
    "Retro": {
        "bg": "#100b20", "surface": "#1b1233", "paper": "#211737", "ink": "#f7edff",
        "chrome": "#160e2b", "accent": "#e34cff", "muted": "#a99bc9",
        "gutter": "#10091f", "particles": ["#ff39d4", "#00f0ff", "#a34dff"], "kind": "tron"
    }
}

class WordProcessor:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1280x850")
        self.root.minsize(900, 620)
        self.root.title(APP)
        self.path = None
        self.dirty = False
        self.loading = False
        self.page_width, self.page_height = 8.5, 11.0
        self.margin_left = self.margin_right = self.margin_top = self.margin_bottom = 1.0
        self.mirror_margins = False
        self.font_family, self.font_size = "Arial", 11
        self.theme_name = "Retro"
        self.particles = []
        self.recent_limit = 12
        self.recent_files = self._load_recent_files()
        self.background_photo_path = ""
        self.photo_opacity = 0.32
        self.editor_photo_opacity = 0.08
        self.outline_photo_opacity = 0.20
        self.panel_photo_opacity = 0.35
        self._load_settings()
        self.read_window = None
        self.pdf_document = None
        self.pdf_page_index = 0
        self.pdf_image_ref = None
        self._build_ui()
        self.ribbon_holder.pack_forget()
        self.body.pack_forget()
        self._show_landing_page()
        self._configure_tags()
        self.editor.edit_modified(False)
        self.editor.bind("<<Modified>>", self.on_modified)
        self.editor.bind("<Control-s>", lambda e: self.save())
        self.editor.bind("<Control-o>", lambda e: self.open_doc())
        self.editor.bind("<Control-n>", lambda e: self.new_doc())
        self.editor.bind("<Control-b>", lambda e: self.toggle("bold"))
        self.editor.bind("<Control-i>", lambda e: self.toggle("italic"))
        self.editor.bind("<Control-u>", lambda e: self.toggle("underline"))
        self.editor.bind("<Control-f>", lambda e: self.find())
        self.editor.bind("<Control-p>", lambda e: self.print_doc())
        self.editor.bind("<Control-Return>", lambda e: self.insert_page_break())
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.apply_theme(self.theme_name)
        self._refresh_status()
        self.root.after(AUTOSAVE_MS, self.autosave_tick)
        self.root.after(70, self.animate_gutters)

    def _build_ui(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        self.style = style
        style.configure("Ribbon.TFrame", background="#f7f8fa")
        style.configure("TButton", padding=(10, 6), relief="flat", borderwidth=0,
                        font=("Segoe UI", 9, "bold"))
        style.map("TButton", relief=[("pressed", "sunken"), ("active", "raised")])
        style.configure("TNotebook", background="#26203d", borderwidth=0, tabmargins=(3, 4, 3, 0))
        style.configure("TNotebook.Tab", padding=(14, 7), font=("Segoe UI", 9, "bold"))
        style.map("TNotebook.Tab", padding=[("selected", (16, 8))])
        style.configure("Status.TLabel", padding=(9, 5))
        self.root.configure(bg="#171b20")
        self.root_photo_label = tk.Label(self.root, bd=0, highlightthickness=0)
        self.root_photo_label.place(x=0, y=0, relwidth=1, relheight=1)
        self.root_photo_label.lower()
        self.root.bind("<Configure>", lambda e: self._apply_photo_backgrounds() if e.widget is self.root else None)

        top = tk.Frame(self.root, bg="#392d27", height=44)
        top.pack(fill="x"); top.pack_propagate(False)
        tk.Label(top, text="WORDLESS", font=("Segoe UI", 12, "bold"),
                 fg="#fff5e8", bg="#392d27").pack(side="left", padx=14)
        tk.Label(top, text="writing studio", font=("Segoe UI", 8),
                 fg="#d8bca7", bg="#392d27").pack(side="left", padx=8)
        tk.Label(top, text="THEME", font=("Segoe UI", 8, "bold"),
                 fg="#d8bca7", bg="#392d27").pack(side="right", padx=(6, 4))
        self.theme_choice = ttk.Combobox(top, width=20, state="readonly", values=list(THEMES.keys()))
        self.theme_choice.set("Retro")
        self.theme_choice.pack(side="right", padx=12, pady=7)
        self.theme_choice.bind("<<ComboboxSelected>>", lambda e: self.apply_theme(self.theme_choice.get()))
        self.themes_button = tk.Button(top, text="Themes…", command=self.open_theme_settings, relief="flat", cursor="hand2",
                  bg="#392d27", fg="#fff0d8", activebackground="#4b3565", activeforeground="#fff0d8")
        self.themes_button.pack(side="right", padx=(0,8), pady=6)

        ribbon_holder = ttk.Frame(self.root, style="Ribbon.TFrame", padding=(8, 5))
        ribbon_holder.pack(fill="x")
        self.ribbon_holder = ribbon_holder
        self.ribbon_tabs = ttk.Notebook(ribbon_holder)
        self.ribbon_tabs.pack(fill="x")
        self.home_tab = ttk.Frame(self.ribbon_tabs, padding=6)
        self.file_tab = ttk.Frame(self.ribbon_tabs, padding=6)
        self.ribbon_tabs.add(self.home_tab, text="Home")
        self.ribbon_tabs.add(self.file_tab, text="File")

        self._group(self.home_tab, "Clipboard")
        clip = self.home_tab.winfo_children()[-1]
        for label, cmd in [("Cut", lambda: self.editor.event_generate("<<Cut>>")),
                           ("Copy", lambda: self.editor.event_generate("<<Copy>>")),
                           ("Paste", lambda: self.editor.event_generate("<<Paste>>")),
                           ("Select All", self.select_all)]:
            ttk.Button(clip, text=label, command=cmd).pack(side="left", padx=2)
        self._group(self.home_tab, "Font")
        fg = self.home_tab.winfo_children()[-1]
        self.font_box = ttk.Combobox(fg, width=16, state="readonly", values=sorted(set(tkfont.families(self.root))))
        self.font_box.set(self.font_family); self.font_box.pack(side="left", padx=3)
        self.font_box.bind("<<ComboboxSelected>>", self.apply_font)
        self.size_box = ttk.Combobox(fg, width=4, values=[8,9,10,11,12,14,16,18,20,24,28,36,48,72])
        self.size_box.set(str(self.font_size)); self.size_box.pack(side="left", padx=3)
        self.size_box.bind("<<ComboboxSelected>>", self.apply_size); self.size_box.bind("<Return>", self.apply_size)
        for label, tag in [("B","bold"),("I","italic"),("U","underline")]:
            ttk.Button(fg, text=label, width=3, command=lambda t=tag:self.toggle(t)).pack(side="left", padx=2)
        self._group(self.home_tab, "Paragraph")
        pg = self.home_tab.winfo_children()[-1]
        for label, alignment in [("Left","left"),("Center","center"),("Right","right"),("Justify","justify")]:
            ttk.Button(pg, text=label, command=lambda a=alignment:self.align(a)).pack(side="left", padx=2)
        ttk.Button(pg, text="• Bullets", command=self.bullets).pack(side="left", padx=2)
        ttk.Button(pg, text="Heading 1", command=lambda:self.apply_heading("heading1")).pack(side="left", padx=2)
        ttk.Button(pg, text="Heading 2", command=lambda:self.apply_heading("heading2")).pack(side="left", padx=2)

        for label,cmd in [("Home",self.show_home),("New",self.new_doc),("Open…",self.open_doc),("Save",self.save),
                          ("Save As…",self.save_as),("Print",self.print_doc)]:
            ttk.Button(self.file_tab,text=label,command=cmd).pack(side="left",padx=5,pady=6)

        # The outline and animated gutters are separate sibling widgets; nothing is drawn over the editor.
        body = tk.Frame(self.root, bg="#dce2e9")
        body.pack(fill="both", expand=True)
        self.body = body
        self.outline = tk.Frame(body, width=190, bg="#251d1a")
        self.outline.pack(side="left", fill="y")
        self.outline.pack_propagate(False)
        self.outline_title = tk.Label(self.outline, text="DOCUMENT OUTLINE", anchor="w",
                                      font=("Segoe UI", 9, "bold"), padx=12, pady=13,
                                      bg="#251d1a", fg="#e9c7a6")
        self.outline_title.pack(fill="x")
        self.outline_hint = tk.Label(self.outline, text="Apply Heading 1 or Heading 2\nfor navigation links.",
                                     justify="left", anchor="nw", font=("Segoe UI", 9),
                                     padx=12, pady=8, bg="#251d1a", fg="#b8a18e")
        self.outline_hint.pack(fill="x")
        self.outline_list = tk.Frame(self.outline, bg="#251d1a")
        self.outline_list.pack(fill="both", expand=True)
        self.writing_card = tk.Frame(self.outline, bg="#392d45", padx=10, pady=10)
        self.writing_card.pack(side="bottom", fill="x", padx=8, pady=9)
        tk.Label(self.writing_card, text="✧ WRITING COMPANION", anchor="w",
                 font=("Segoe UI", 9, "bold"), bg="#392d45", fg="#fff0d8").pack(fill="x", pady=(0,5))
        self.writing_buttons = []
        for label, command in [("✦ Spark an idea", self.writing_prompt),
                               ("☾ Build an outline", self.outline_starter),
                               ("✧ Unblock my writing", self.writer_block),
                               ("✓ Revision checklist", self.revision_checklist)]:
            btn = tk.Button(self.writing_card, text=label, anchor="w", command=command,
                            relief="flat", bd=0, padx=8, pady=6, cursor="hand2",
                            font=("Segoe UI", 9, "bold"), bg="#4a345e", fg="#fff0d8",
                            activebackground="#ff76b7", activeforeground="#211b35")
            btn.pack(fill="x", pady=2)
            self.writing_buttons.append(btn)

        self.left_gutter = tk.Canvas(body, width=44, highlightthickness=0, bd=0, bg="#251d1a")
        self.left_gutter.pack(side="left", fill="y")
        self.editor_column = tk.Frame(body, bg="#fffaf0")
        self.editor_column.pack(side="left", fill="both", expand=True, padx=0, pady=10)
        self.top_ruler = tk.Canvas(self.editor_column, height=27, highlightthickness=0, bd=0, bg="#fffaf0")
        self.top_ruler.pack(side="top", fill="x")
        self.editor_frame = tk.Frame(self.editor_column, bg="#fffaf0", bd=1, relief="solid")
        self.editor_frame.pack(side="top", fill="both", expand=True)
        self.left_ruler = tk.Canvas(self.editor_frame, width=28, highlightthickness=0, bd=0, bg="#fffaf0")
        self.left_ruler.pack(side="left", fill="y")
        self.editor = tk.Text(self.editor_frame, wrap="word", undo=True, maxundo=-1,
                              font=(self.font_family,self.font_size), bg="#fffaf0", fg="#2d2925",
                              insertbackground="#2d2925", padx=42, pady=30, spacing1=2, spacing3=5,
                              borderwidth=0, relief="flat", selectbackground="#b9d7ff")
        sy=ttk.Scrollbar(self.editor_frame,orient="vertical",command=self.editor.yview)
        self.editor.configure(yscrollcommand=sy.set)
        self.editor.pack(side="left",fill="both",expand=True); sy.pack(side="right",fill="y")
        self.top_ruler.bind("<Configure>", lambda e: self._draw_rulers())
        self.left_ruler.bind("<Configure>", lambda e: self._draw_rulers())
        self.right_gutter = tk.Canvas(body, width=44, highlightthickness=0, bd=0, bg="#251d1a")
        self.right_gutter.pack(side="left", fill="y")
        self.left_gutter.bind("<Configure>", lambda e: self._apply_photo_backgrounds())
        self.right_gutter.bind("<Configure>", lambda e: self._apply_photo_backgrounds())
        self.landing_frame = tk.Frame(self.root, bg="#171326")
        self.landing_frame.pack(fill="both", expand=True)
        self._build_landing_page()
        self.status=ttk.Label(self.root,anchor="w",padding=(9,5))
        self.status.pack(fill="x",side="bottom")

    def _settings_path(self):
        base = (os.environ.get("APPDATA") or os.path.expanduser("~")) if sys.platform.startswith("win") else (os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config"))
        folder = os.path.join(base, "Wordless")
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "settings.json")

    def _load_settings(self):
        try:
            with open(self._settings_path(), "r", encoding="utf-8") as f: data = json.load(f)
            if data.get("theme") in THEMES: self.theme_name = data["theme"]
            self.background_photo_path = data.get("background_photo_path", "")
            for attr in ("photo_opacity", "editor_photo_opacity", "outline_photo_opacity", "panel_photo_opacity"):
                try: setattr(self, attr, max(0.0, min(1.0, float(data.get(attr, getattr(self, attr))))) )
                except (TypeError, ValueError): pass
        except (OSError, ValueError, TypeError): pass

    def _save_settings(self):
        try:
            with open(self._settings_path(), "w", encoding="utf-8") as f:
                json.dump({"theme": self.theme_name, "background_photo_path": self.background_photo_path,
                    "photo_opacity": self.photo_opacity, "editor_photo_opacity": self.editor_photo_opacity,
                    "outline_photo_opacity": self.outline_photo_opacity, "panel_photo_opacity": self.panel_photo_opacity}, f, indent=2)
        except OSError: pass

    def open_theme_settings(self):
        t = THEMES[self.theme_name]
        win = tk.Toplevel(self.root); win.title("Themes and Background | Wordless"); win.transient(self.root); win.grab_set(); win.configure(bg=t["bg"]); win.geometry("560x500")
        tk.Label(win, text="THEMES & PERSONAL BACKGROUND", font=("Segoe UI", 14, "bold"), bg=t["bg"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["accent"])).pack(anchor="w", padx=20, pady=(18,8))
        tk.Label(win, text="Choose a local image. The path and opacity settings are stored on this device.", wraplength=490, justify="left", bg=t["bg"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["muted"])).pack(anchor="w", padx=20, pady=(0,12))
        current = tk.StringVar(value=self.background_photo_path or "No photo selected")
        row = tk.Frame(win, bg=t["bg"]); row.pack(fill="x", padx=20, pady=6)
        tk.Label(row, textvariable=current, bg=t["surface"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"]), anchor="w", padx=8, pady=8).pack(side="left", fill="x", expand=True)
        def choose_photo():
            path = filedialog.askopenfilename(parent=win, title="Choose background photo", filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"), ("All files", "*.*")])
            if path:
                if Image is None:
                    messagebox.showerror("Image support", "Install Pillow to use background photos. Run build_windows.bat again.", parent=win); return
                try: Image.open(path).verify()
                except Exception as exc: messagebox.showerror("Invalid image", str(exc), parent=win); return
                self.background_photo_path = path; current.set(path); self._save_settings()
        tk.Button(row, text="Choose photo…", command=choose_photo, bg=t["accent"], fg=t["bg"], relief="flat", padx=10, pady=7).pack(side="left", padx=(8,0))
        def clear_photo():
            self.background_photo_path = ""; current.set("No photo selected"); self._save_settings()
        tk.Button(row, text="Clear", command=clear_photo, bg=t["surface"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"]), relief="flat", padx=10, pady=7).pack(side="left", padx=(6,0))
        vars_and_labels = [("App background visibility", "photo_opacity"), ("Writing area theme blend", "editor_photo_opacity"), ("Outline theme blend", "outline_photo_opacity"), ("Panels theme blend", "panel_photo_opacity")]
        scales = {}
        for label, attr in vars_and_labels:
            line = tk.Frame(win, bg=t["bg"]); line.pack(fill="x", padx=20, pady=5)
            tk.Label(line, text=label, width=27, anchor="w", bg=t["bg"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"])).pack(side="left")
            var = tk.DoubleVar(value=getattr(self, attr)); scales[attr] = var
            tk.Scale(line, from_=0, to=1, resolution=.05, orient="horizontal", showvalue=True, variable=var, bg=t["bg"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"]), troughcolor=t["surface"], highlightthickness=0, length=200).pack(side="left", fill="x", expand=True)
        tk.Label(win, text="The photo is blended into the animated side margins. Other sliders tune theme-color blending for focus; the editable text surface remains solid for legibility.", wraplength=510, bg=t["bg"], fg=t["muted"], justify="left").pack(anchor="w", padx=20, pady=8)
        def reset_background_and_settings():
            self.background_photo_path = ""
            self.photo_opacity = 0.32
            self.editor_photo_opacity = 0.08
            self.outline_photo_opacity = 0.20
            self.panel_photo_opacity = 0.35
            current.set("No photo selected")
            for attr, default in (("photo_opacity", 0.32), ("editor_photo_opacity", 0.08), ("outline_photo_opacity", 0.20), ("panel_photo_opacity", 0.35)):
                scales[attr].set(default)
            self._save_settings()
            self.apply_theme(self.theme_name)
        tk.Button(win, text="Reset personal background & settings", command=reset_background_and_settings, bg=t["surface"], fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"]), activebackground=t["accent"], relief="flat", padx=12, pady=7).pack(anchor="w", padx=20, pady=(4,10))
        def apply():
            for attr, var in scales.items(): setattr(self, attr, var.get())
            self._save_settings(); self.apply_theme(self.theme_name); win.destroy()
        tk.Button(win, text="Apply settings", command=apply, bg=t["accent"], fg=t["bg"], relief="flat", padx=14, pady=8).pack(anchor="e", padx=20, pady=(0,16))

    def _draw_rulers(self):
        if not hasattr(self, "top_ruler"): return
        t = THEMES[self.theme_name]
        for canvas in (self.top_ruler, self.left_ruler): canvas.delete("all")
        w = max(1, self.top_ruler.winfo_width()); h = max(1, self.left_ruler.winfo_height())
        self.top_ruler.configure(bg=t["surface"]); self.left_ruler.configure(bg=t["surface"])
        # Ruler ticks are proportional to the selected paper size and current margins.
        scale = max(1, (w - 24) / self.page_width)
        left = 12 + self.margin_left * scale; right = w - 12 - self.margin_right * scale
        self.top_ruler.create_line(12, 20, w-12, 20, fill=t["muted"])
        self.top_ruler.create_rectangle(left, 3, max(left+1,right), 11, fill=t["accent"], outline="")
        for inch in range(int(self.page_width) + 1):
            x = 12 + inch * scale
            self.top_ruler.create_line(x, 13, x, 24, fill=t["muted"])
            if inch < self.page_width: self.top_ruler.create_text(x+scale/2, 6, text=str(inch), fill=("#FFF0D8" if self.theme_name == "Autumn" else t["ink"]), font=("Segoe UI", 7))
        vscale = max(1, (h - 18) / self.page_height); top = 9 + self.margin_top * vscale; bottom = h - 9 - self.margin_bottom * vscale
        self.left_ruler.create_line(20, 9, 20, h-9, fill=t["muted"])
        self.left_ruler.create_rectangle(3, top, 11, max(top+1,bottom), fill=t["accent"], outline="")
        for inch in range(int(self.page_height) + 1):
            y = 9 + inch * vscale
            self.left_ruler.create_line(13, y, 24, y, fill=t["muted"])
            if inch < self.page_height: self.left_ruler.create_text(6, y+vscale/2, text=str(inch), fill=("#FFF0D8" if self.theme_name == "Autumn" else t["ink"]), font=("Segoe UI", 7), angle=90)

    def open_read_mode(self):
        """Read-only reading layouts: page-by-page paper view or continuous manuscript scroll."""
        t = THEMES[self.theme_name]
        win = tk.Toplevel(self.root); win.title("Read Mode | Wordless"); win.geometry("1100x820"); win.configure(bg=t["bg"])
        bar = tk.Frame(win, bg=t["chrome"], padx=12, pady=8); bar.pack(fill="x")
        tk.Label(bar, text="READ MODE", font=("Segoe UI", 10, "bold"), bg=t["chrome"], fg=t["accent"]).pack(side="left", padx=(0,12))
        mode = tk.StringVar(value="Pages")
        tk.Label(bar, text="View", bg=t["chrome"], fg=t["muted"]).pack(side="left")
        picker = ttk.Combobox(bar, textvariable=mode, state="readonly", values=["Pages", "Manuscript"], width=14)
        picker.pack(side="left", padx=8)
        page_label = tk.Label(bar, text="", bg=t["chrome"], fg=t["muted"]); page_label.pack(side="left", padx=12)
        prev_btn = tk.Button(bar, text="◀ Previous", relief="flat", bg=t["surface"], fg=t["ink"]); prev_btn.pack(side="right", padx=3)
        next_btn = tk.Button(bar, text="Next ▶", relief="flat", bg=t["surface"], fg=t["ink"]); next_btn.pack(side="right", padx=3)
        outer = tk.Frame(win, bg=t["surface"]); outer.pack(fill="both", expand=True, padx=18, pady=14)
        canvas = tk.Canvas(outer, bg=t["surface"], highlightthickness=0)
        scroll = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview); canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        content = tk.Frame(canvas, bg=t["surface"]); canvas_window = canvas.create_window((0,0), window=content, anchor="n")
        full_text = self.editor.get("1.0", "end-1c")
        # Approximate page capacity from actual selected paper dimensions and margins.
        def make_pages():
            chars_per_line = max(35, int((self.page_width-self.margin_left-self.margin_right)*10.5))
            lines_per_page = max(12, int((self.page_height-self.margin_top-self.margin_bottom)*5.2))
            lines=[]
            for paragraph in full_text.splitlines() or [""]:
                if not paragraph: lines.append(""); continue
                while len(paragraph) > chars_per_line:
                    cut=paragraph.rfind(" ",0,chars_per_line)
                    if cut < chars_per_line//2: cut=chars_per_line
                    lines.append(paragraph[:cut]); paragraph=paragraph[cut:].lstrip()
                lines.append(paragraph)
            return ["\n".join(lines[i:i+lines_per_page]) for i in range(0,max(1,len(lines)),lines_per_page)] or [""]
        state={"index":0,"pages":make_pages()}
        def render(*_):
            for child in content.winfo_children(): child.destroy()
            canvas.delete("page")
            if mode.get()=="Pages":
                pages=state["pages"]; state["index"]=max(0,min(state["index"],len(pages)-1))
                page_label.configure(text=f"Page {state['index']+1} of {len(pages)} · {self.page_width:g} × {self.page_height:g} in")
                prev_btn.configure(state="normal" if state["index"]>0 else "disabled"); next_btn.configure(state="normal" if state["index"]<len(pages)-1 else "disabled")
                # Preserve the selected paper's actual aspect ratio in the reading canvas.
                ratio=self.page_height/max(self.page_width,1)
                page_w=min(650,int(740/max(ratio,0.5))); page_h=int(page_w*ratio)
                paper=tk.Frame(content,bg=t["paper"],highlightbackground=t["muted"],highlightthickness=1,width=page_w,height=page_h)
                paper.pack(pady=12); paper.pack_propagate(False)
                text=tk.Text(paper,wrap="word",font=("Georgia",12),bg=t["paper"],fg=t["ink"],relief="flat",bd=0,
                    padx=max(24,int(self.margin_left*28)),pady=max(24,int(self.margin_top*28)),spacing1=2,spacing3=5)
                text.pack(fill="both",expand=True); text.insert("1.0",pages[state["index"]]); text.configure(state="disabled")
                canvas.itemconfigure(canvas_window,anchor="n"); canvas.coords(canvas_window, max(1,canvas.winfo_width()//2), 0)
            else:
                page_label.configure(text="Continuous manuscript · read only"); prev_btn.configure(state="disabled"); next_btn.configure(state="disabled")
                manuscript=tk.Text(content,wrap="word",font=("Georgia",13),bg=t["paper"],fg=t["ink"],relief="flat",bd=0,
                    padx=100,pady=42,spacing1=3,spacing3=7,width=95)
                manuscript.pack(fill="both",expand=True,padx=80,pady=12); manuscript.insert("1.0",full_text); manuscript.configure(state="disabled")
                canvas.itemconfigure(canvas_window,anchor="n"); canvas.coords(canvas_window,max(1,canvas.winfo_width()//2),0)
            content.update_idletasks(); canvas.configure(scrollregion=canvas.bbox("all"))
        prev_btn.configure(command=lambda:(state.update(index=max(0,state["index"]-1)),render()))
        next_btn.configure(command=lambda:(state.update(index=min(len(state["pages"])-1,state["index"]+1)),render()))
        mode.trace_add("write",render)
        canvas.bind("<Configure>",lambda e:canvas.coords(canvas_window,max(1,e.width//2),0))
        render()
        tk.Label(win,text="Read-only view. Page mode approximates pagination; Manuscript is continuous scrolling.",bg=t["bg"],fg=t["muted"]).pack(anchor="w",padx=22,pady=(0,10))
        self.read_window=win

    def open_pdf(self, path):
        if not PDF_OK:
            try:
                if sys.platform.startswith("win"): os.startfile(path)
                elif sys.platform == "darwin": subprocess.Popen(["open", path])
                else: subprocess.Popen(["xdg-open", path])
                self._remember_file(path)
            except Exception as exc: messagebox.showerror("Open PDF", f"Could not open this PDF. Install PyMuPDF and Pillow for the built-in viewer.\n{exc}")
            return
        try:
            doc = fitz.open(path)
            if not len(doc): raise ValueError("The PDF has no pages.")
            self.pdf_document = doc; self.pdf_page_index = 0; self.pdf_path = os.path.abspath(path)
            win = tk.Toplevel(self.root); win.title(f"{os.path.basename(path)} | Wordless PDF Reader"); win.geometry("1000x800"); win.configure(bg=THEMES[self.theme_name]["bg"])
            self.pdf_window = win
            bar = tk.Frame(win, bg=THEMES[self.theme_name]["chrome"], padx=10, pady=8); bar.pack(fill="x")
            self.pdf_page_label = tk.Label(bar, text="", bg=THEMES[self.theme_name]["chrome"], fg=THEMES[self.theme_name]["accent"]); self.pdf_page_label.pack(side="left", padx=10)
            tk.Button(bar, text="◀ Previous", command=lambda:self._show_pdf_page(-1), relief="flat", bg=THEMES[self.theme_name]["surface"], fg=THEMES[self.theme_name]["ink"]).pack(side="left", padx=3)
            tk.Button(bar, text="Next ▶", command=lambda:self._show_pdf_page(1), relief="flat", bg=THEMES[self.theme_name]["surface"], fg=THEMES[self.theme_name]["ink"]).pack(side="left", padx=3)
            tk.Label(bar, text="Read-only PDF · no editing", bg=THEMES[self.theme_name]["chrome"], fg=THEMES[self.theme_name]["muted"]).pack(side="right", padx=8)
            pdf_body = tk.Frame(win, bg=THEMES[self.theme_name]["bg"]); pdf_body.pack(fill="both", expand=True)
            self.pdf_canvas = tk.Canvas(pdf_body, bg=THEMES[self.theme_name]["bg"], highlightthickness=0)
            pdf_scroll = ttk.Scrollbar(pdf_body, orient="vertical", command=self.pdf_canvas.yview)
            self.pdf_canvas.configure(yscrollcommand=pdf_scroll.set)
            self.pdf_canvas.pack(side="left", fill="both", expand=True); pdf_scroll.pack(side="right", fill="y")
            self.pdf_canvas.bind("<Configure>", lambda e:self._render_pdf_page())
            win.protocol("WM_DELETE_WINDOW", lambda:(self.pdf_document.close() if self.pdf_document else None, win.destroy()))
            self._remember_file(path); self._show_pdf_page(0)
        except Exception as exc: messagebox.showerror("Open PDF", str(exc), parent=self.root)

    def _show_pdf_page(self, delta):
        if not self.pdf_document: return
        self.pdf_page_index = max(0, min(len(self.pdf_document)-1, self.pdf_page_index + delta))
        self._render_pdf_page()

    def _render_pdf_page(self):
        if not self.pdf_document or not hasattr(self, "pdf_canvas"): return
        try:
            page = self.pdf_document[self.pdf_page_index]
            width = max(400, self.pdf_canvas.winfo_width()-50)
            pix = page.get_pixmap(matrix=fitz.Matrix(width/page.rect.width, width/page.rect.width), alpha=False)
            image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            self.pdf_image_ref = ImageTk.PhotoImage(image)
            self.pdf_canvas.delete("all"); self.pdf_canvas.create_image(max(12,(self.pdf_canvas.winfo_width()-pix.width)//2), 12, image=self.pdf_image_ref, anchor="nw")
            self.pdf_canvas.configure(scrollregion=(0,0,pix.width+24,pix.height+24))
            self.pdf_page_label.configure(text=f"Page {self.pdf_page_index+1} of {len(self.pdf_document)}")
        except Exception as exc: self.pdf_canvas.delete("all"); self.pdf_canvas.create_text(20,20,anchor="nw",text=f"Could not render page: {exc}",fill="white")

    def _recent_store_path(self):
        """Return a per-user local settings path for the recent-file list."""
        if sys.platform.startswith("win"):
            base = os.environ.get("APPDATA") or os.path.expanduser("~")
        else:
            base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
        folder = os.path.join(base, "Wordless")
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "recent_files.json")

    def _load_recent_files(self):
        try:
            with open(self._recent_store_path(), "r", encoding="utf-8") as f:
                paths = json.load(f)
            if not isinstance(paths, list): return []
            return [os.path.abspath(x) for x in paths if isinstance(x, str) and os.path.isfile(x)][:12]
        except (OSError, ValueError, TypeError):
            return []

    def _save_recent_files(self):
        try:
            with open(self._recent_store_path(), "w", encoding="utf-8") as f:
                json.dump(self.recent_files[:self.recent_limit], f, indent=2)
        except OSError:
            pass

    def _remember_file(self, path):
        if not path: return
        path = os.path.abspath(path)
        if not os.path.isfile(path): return
        self.recent_files = [p for p in self.recent_files if os.path.normcase(p) != os.path.normcase(path)]
        self.recent_files.insert(0, path)
        self.recent_files = self.recent_files[:self.recent_limit]
        self._save_recent_files()
        if hasattr(self, "recent_list_frame"):
            self._refresh_recent_files()

    def _build_landing_page(self):
        self.landing_content = tk.Frame(self.landing_frame, bg="#171326")
        self.landing_content.pack(fill="both", expand=True, padx=44, pady=24)
        # Keep the welcome page uncluttered: no subtitle above the greeting.
        self.landing_eyebrow = None
        self.landing_greetings = ["Aloha", "Buenos dias", "Hello There", "Bienvenue Mon Ami", "Oi.", "Hehe", "Ollo?", "Welcome Back", "Willkommen", "Yellow?"]
        self.landing_heading = tk.Label(self.landing_content, text=random.choice(self.landing_greetings),
            font=("Segoe UI", 28, "bold"), bg="#171326", fg="#fff4ff")
        self.landing_heading.pack(anchor="w")
        actions = tk.Frame(self.landing_content, bg="#171326")
        actions.pack(anchor="w", pady=(0, 22))
        self._landing_action(actions, "＋  New document", self.new_doc, "#ff76b7").pack(side="left", padx=(0, 10))
        self._landing_action(actions, "↗  Open a file…", self.open_doc, "#7ce7ff").pack(side="left", padx=(0, 10))

        theme = THEMES[self.theme_name]
        section = tk.Frame(self.landing_content, bg=theme["surface"], padx=18, pady=14,
                           highlightthickness=1, highlightbackground=theme["accent"])
        section.pack(fill="both", expand=True)
        header = tk.Frame(section, bg=theme["surface"])
        header.pack(fill="x", pady=(0, 8))
        tk.Label(header, text="JUMP BACK IN", font=("Segoe UI", 11, "bold"),
                 bg=theme["surface"], fg=("#fff0d8" if self.theme_name == "Autumn" else theme["accent"])).pack(side="left")
        tk.Label(header, text="Saved on this device · up to 12 files", font=("Segoe UI", 9),
                 bg=theme["surface"], fg=theme["muted"]).pack(side="right")
        self.recent_list_frame = tk.Frame(section, bg=theme["surface"])
        self.recent_list_frame.pack(fill="both", expand=True)
        self.recent_section = section
        self.recent_header = header
        self._refresh_recent_files()
        self.landing_footer = tk.Label(self.landing_content,
            text="Offline by design. Your recent-file list is stored locally on this device.",
            font=("Segoe UI", 9), bg=theme["bg"], fg=theme["muted"])
        footer = self.landing_footer
        footer.pack(anchor="w", pady=(12, 0))

    def _landing_action(self, parent, label, command, accent):
        return tk.Button(parent, text=label, command=command, cursor="hand2",
            font=("Segoe UI", 10, "bold"), relief="flat", bd=0, padx=18, pady=12,
            bg="#35234d", fg=accent, activebackground=accent, activeforeground="#171326")

    def _refresh_recent_files(self):
        if not hasattr(self, "recent_list_frame"): return
        for child in self.recent_list_frame.winfo_children(): child.destroy()
        t = THEMES[self.theme_name]
        panel_bg = t["surface"]
        text_fg = "#fff0d8" if self.theme_name == "Autumn" else t["ink"]
        link_fg = "#fff0d8" if self.theme_name == "Autumn" else t["accent"]
        muted_fg = t["muted"]
        valid = []
        for path in self.recent_files:
            if os.path.isfile(path): valid.append(path)
        if valid != self.recent_files:
            self.recent_files = valid[:self.recent_limit]
            self._save_recent_files()
        if not valid:
            tk.Label(self.recent_list_frame, text="No recent documents yet. Start something new or open a file to see it here.",
                     font=("Segoe UI", 10), bg=panel_bg, fg=muted_fg, pady=24).pack(anchor="w")
            return
        for path in valid:
            row = tk.Frame(self.recent_list_frame, bg=panel_bg, pady=5)
            row.pack(fill="x")
            name = os.path.basename(path)
            tk.Button(row, text="✧  " + name, command=lambda p=path:self.open_recent_file(p),
                anchor="w", cursor="hand2", relief="flat", bd=0, bg=panel_bg, fg=text_fg,
                activebackground=t["chrome"], activeforeground=link_fg,
                font=("Segoe UI", 10, "bold"), padx=8, pady=5).pack(side="left", fill="x", expand=True)
            tk.Button(row, text="Open folder ↗", command=lambda p=path:self.open_file_location(p),
                cursor="hand2", relief="flat", bd=0, bg=panel_bg, fg=link_fg,
                activebackground=t["chrome"], activeforeground=link_fg,
                font=("Segoe UI", 9), padx=8, pady=5).pack(side="right")
            tk.Label(self.recent_list_frame, text=path, anchor="w", font=("Segoe UI", 8),
                bg=panel_bg, fg=muted_fg).pack(fill="x", padx=(31, 0))
            tk.Frame(self.recent_list_frame, bg=t["gutter"], height=1).pack(fill="x", pady=(4, 0))

    def _show_landing_page(self):
        self.ribbon_holder.pack_forget()
        self.body.pack_forget()
        self.landing_frame.pack(fill="both", expand=True, before=self.status)
        self._refresh_recent_files()

    def show_home(self):
        if not self.confirm_discard(): return
        self._show_landing_page()

    def _show_editor(self):
        self.landing_frame.pack_forget()
        self.ribbon_holder.pack(fill="x", before=self.status)
        self.body.pack(fill="both", expand=True, before=self.status)

    def open_recent_file(self, path):
        if not self.confirm_discard(): return
        self._open_path(path)

    def open_file_location(self, path):
        if not os.path.isfile(path):
            messagebox.showwarning("File unavailable", "This file no longer exists on this device.")
            self._refresh_recent_files()
            return
        folder = os.path.dirname(os.path.abspath(path))
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
            else:
                webbrowser.open("file://" + folder)
        except Exception as e:
            messagebox.showerror("Could not open folder", str(e))

    def _group(self,parent,title):
        box=ttk.LabelFrame(parent,text=title,padding=5); box.pack(side="left",fill="y",padx=(0,7)); return box

    def apply_theme(self,name):
        if name not in THEMES:return
        self.theme_name=name; t=THEMES[name]
        self.root.configure(bg=t["bg"])
        # Recolor title strip and document navigation chrome.
        for widget in self.root.winfo_children():
            if isinstance(widget,tk.Frame) and widget.winfo_children():
                first=widget.winfo_children()[0]
                if isinstance(first,tk.Label) and "WORDLESS" in str(first.cget("text")):
                    widget.configure(bg=t["chrome"])
                    for child in widget.winfo_children():
                        if isinstance(child,tk.Label):
                            child.configure(bg=t["chrome"],fg=("#fff0d8" if self.theme_name=="Autumn" else t["muted"]) if child.cget("text")!="WORDLESS" else "#ffffff")
                for child in widget.winfo_children():
                    if isinstance(child, tk.Button) and child.cget("text") == "Themes…": child.configure(bg=t["chrome"], fg=t["ink"], activebackground=t["surface"])
        for w in (self.outline,self.outline_list):
            w.configure(bg=t["surface"])
        self.outline_title.configure(bg=t["surface"], fg=("#fff0d8" if name == "Autumn" else t["accent"]), font=("Segoe UI", 12, "bold"))
        self.outline_hint.configure(bg=t["surface"], fg=("#fff0d8" if name == "Autumn" else t["muted"]), font=("Segoe UI", 11))
        # Keep native font controls and the Themes button readable in Autumn.
        if hasattr(self, "themes_button"):
            self.themes_button.configure(bg=t["chrome"], fg="#fff0d8" if name == "Autumn" else t["accent"], activebackground=t["surface"], activeforeground="#fff0d8" if name == "Autumn" else t["accent"])
        for attr in ("size_box", "font_box", "font_size_combo", "font_size_choice", "font_size_box"):
            control = getattr(self, attr, None)
            if control is not None:
                try: control.configure(foreground="#fff0d8" if name == "Autumn" else t["ink"], background=t["surface"], fieldbackground=t["surface"], arrowcolor="#fff0d8" if name == "Autumn" else t["accent"])
                except tk.TclError: pass
        self.left_gutter.configure(bg=t["gutter"]); self.right_gutter.configure(bg=t["gutter"])
        self.editor_frame.configure(bg=t["paper"])
        self.editor.configure(bg=t["paper"],fg=t["ink"],insertbackground=t["ink"])
        self.editor_column.configure(bg=t["surface"])
        self.top_ruler.configure(bg=t["surface"]); self.left_ruler.configure(bg=t["surface"])
        self.body.configure(bg=t["bg"])
        self.outline.configure(bg=t["surface"]); self.outline_list.configure(bg=t["surface"])
        self._draw_rulers()
        self.status.configure(background=t["bg"],foreground=t["muted"])
        # Coordinated retro controls: jewel-toned surfaces, luminous accent, tactile hover.
        try:
            control_fg = "#fff0d8" if self.theme_name == "Autumn" else t["ink"]
            tab_fg = "#fff0d8" if self.theme_name == "Autumn" else t["muted"]
            self.style.configure("TButton", background=t["surface"], foreground=control_fg,
                                 padding=(10, 6), relief="flat", borderwidth=1,
                                 bordercolor=t["accent"], focusthickness=1, focuscolor=t["accent"])
            self.style.map("TButton", background=[("pressed", t["accent"]), ("active", t["chrome"])],
                           foreground=[("pressed", t["bg"]), ("active", t["accent"])])
            self.style.configure("TNotebook", background=t["bg"], borderwidth=0)
            self.style.configure("TNotebook.Tab", background=t["surface"], foreground=tab_fg,
                                 padding=(14, 7), font=("Segoe UI", 9, "bold"))
            selected_fg = "#fff0d8" if self.theme_name == "Autumn" else t["accent"]
            self.style.map("TNotebook.Tab", background=[("selected", t["chrome"]), ("active", t["surface"])],
                           foreground=[("selected", selected_fg), ("active", control_fg)])
            self.style.configure("TCombobox", fieldbackground=t["surface"], background=t["surface"],
                                 foreground=("#fff0d8" if name == "Autumn" else t["ink"]), arrowcolor=("#fff0d8" if name == "Autumn" else t["accent"]))
            self.style.map("TCombobox", foreground=[("readonly", "#fff0d8" if name == "Autumn" else t["ink"])], fieldbackground=[("readonly", t["surface"])])
        except tk.TclError: pass
        if hasattr(self, "writing_card"):
            # Snowy uses a light card and dark text; other themes use their own coordinated palette.
            companion_bg = "#f7f8fa" if name == "Snowy" else t["chrome"]
            companion_fg = "#1f2937" if name == "Snowy" else ("#fff0d8" if name == "Autumn" else t["accent"])
            button_bg = "#ffffff" if name == "Snowy" else t["surface"]
            button_fg = "#1f2937" if name == "Snowy" else ("#fff0d8" if name == "Autumn" else t["ink"])
            self.writing_card.configure(bg=companion_bg)
            for child in self.writing_card.winfo_children():
                if isinstance(child, tk.Label): child.configure(bg=companion_bg, fg=companion_fg)
                elif isinstance(child, tk.Button):
                    child.configure(bg=button_bg, fg=button_fg, activebackground=("#dcecff" if name == "Snowy" else t["accent"]),
                                   activeforeground=("#1f2937" if name == "Snowy" else t["bg"]))
        if hasattr(self, "landing_frame"):
            self.landing_frame.configure(bg=t["bg"])
            if hasattr(self, "landing_content"):
                self.landing_content.configure(bg=t["bg"])
                # Re-theme every landing-page container and text element instead of
                # leaving the original Retro palette baked into the Home screen.
                if self.landing_eyebrow is not None:
                    self.landing_eyebrow.configure(bg=t["bg"])
                self.landing_heading.configure(bg=t["bg"])
                if hasattr(self, "landing_footer"):
                    self.landing_footer.configure(bg=t["bg"], fg=t["muted"])
                if self.landing_eyebrow is not None:
                    self.landing_eyebrow.configure(fg=("#fff0d8" if name == "Autumn" else t["accent"]))
                self.landing_heading.configure(fg=("#fff0d8" if name == "Autumn" else t["ink"]))
                for child in self.landing_content.winfo_children():
                    if isinstance(child, tk.Frame):
                        child.configure(bg=t["bg"])
                        for nested in child.winfo_children():
                            try:
                                if isinstance(nested, tk.Button):
                                    nested.configure(bg=t["surface"], fg=("#fff0d8" if name == "Autumn" else t["accent"]), activebackground=t["accent"], activeforeground=t["bg"])
                            except tk.TclError: pass
                if hasattr(self, "recent_section"):
                    self.recent_section.configure(bg=t["surface"], highlightbackground=t["accent"])
                    self.recent_header.configure(bg=t["surface"])
                    for item in self.recent_header.winfo_children():
                        item.configure(bg=t["surface"], fg=("#fff0d8" if name == "Autumn" else t["accent"]) if item is self.recent_header.winfo_children()[0] else t["muted"])
                # Recreate rows and separators with the active theme; otherwise the
                # old Retro purple divider color can remain after changing themes.
                self._refresh_recent_files()
                if hasattr(self, "recent_list_frame"):
                    self.recent_list_frame.configure(bg=t["surface"])
                    self._refresh_recent_files()
        self._configure_tags()
        self._refresh_outline()
        if hasattr(self,"theme_choice"): self.theme_choice.set(name)
        self._recolor_tree(self.root, t)
        if hasattr(self, "recent_list_frame"): self._refresh_recent_files()
        self._recolor_tree(self.root, t)
        self._apply_photo_backgrounds()
        self._draw_rulers()
        self._save_settings()
        self._seed_particles()

    def _recolor_tree(self, widget, t):
        """Recolor native Tk panels too, not only ttk controls, so theme changes are consistent."""
        bg_map = {
            "#171326": t["bg"], "#26203d": t["surface"], "#392d27": t["chrome"],
            "#251d1a": t["surface"], "#392d45": t["chrome"], "#4a345e": t["surface"],
            "#35234d": t["chrome"], "#403455": t["gutter"], "#151126": t["gutter"],
            "#fffaf0": t["paper"], "#dce2e9": t["gutter"], "#fff4ff": t["ink"],
            "#f7edff": t["ink"], "#c8b6e8": t["muted"], "#9686b5": t["muted"],
            "#d8bca7": t["muted"], "#b8a18e": t["muted"], "#ffd166": t["accent"],
            "#ff76b7": t["accent"], "#7ce7ff": t["accent"], "#fff5e8": t["ink"]
        }
        try:
            if widget.winfo_class() in ("Frame", "LabelFrame", "Canvas", "Label", "Button", "Text", "Entry"):
                old = str(widget.cget("bg")).lower()
                if old in bg_map:
                    new = bg_map[old]
                    opts = {"bg": new}
                    try:
                        fg = str(widget.cget("fg")).lower()
                        fg_map = {"#fff4ff": t["ink"], "#f7edff": t["ink"], "#c8b6e8": t["muted"], "#9686b5": t["muted"], "#d8bca7": t["muted"], "#b8a18e": t["muted"], "#ffd166": t["accent"], "#ff76b7": t["accent"], "#7ce7ff": t["accent"]}
                        if fg in fg_map: opts["fg"] = fg_map[fg]
                    except tk.TclError: pass
                    try: widget.configure(**opts)
                    except tk.TclError: pass
        except tk.TclError: pass
        # Keep key navigation and settings controls readable in Autumn regardless of inherited native-widget colors.
        if self.theme_name == "Autumn":
            if hasattr(self, "outline_title"): self.outline_title.configure(fg="#fff0d8", font=("Segoe UI", 12, "bold"))
            if hasattr(self, "outline_hint"): self.outline_hint.configure(fg="#fff0d8", font=("Segoe UI", 11))
            if hasattr(self, "themes_button"): self.themes_button.configure(fg="#fff0d8", activeforeground="#fff0d8")
        if hasattr(self, "writing_card"):
            for widget in self.writing_card.winfo_children():
                try:
                    if isinstance(widget, tk.Label):
                        widget.configure(fg=("#1f2937" if self.theme_name == "Snowy" else "#fff0d8" if self.theme_name == "Autumn" else t["accent"]))
                    elif isinstance(widget, tk.Button):
                        widget.configure(fg=("#1f2937" if self.theme_name == "Snowy" else "#fff0d8" if self.theme_name == "Autumn" else t["ink"]),
                                         activeforeground=("#1f2937" if self.theme_name == "Snowy" else "#211b35" if self.theme_name == "Autumn" else t["bg"]))
                except tk.TclError:
                    pass

        # Native buttons/labels with legacy dark text are corrected for dark themes.
        try:
            if widget.winfo_class() in ("Button", "Label", "Radiobutton", "Checkbutton"):
                fg = str(widget.cget("fg")).lower()
                if fg in ("#222222", "#2d2925", "#171b20", "#160e2b", "#392d27"):
                    widget.configure(fg=t["ink"])
        except tk.TclError: pass
        for child in widget.winfo_children(): self._recolor_tree(child, t)

    def _apply_photo_backgrounds(self):
        """Use a persistent local photo as a soft app backdrop and blend it into edge panels."""
        if Image is None or not self.background_photo_path or not os.path.isfile(self.background_photo_path):
            for canvas_name in ("left_gutter", "right_gutter"):
                canvas = getattr(self, canvas_name, None)
                if canvas is not None:
                    try: canvas.delete("background-photo")
                    except tk.TclError: pass
            if hasattr(self, "root_photo_label"):
                self.root_photo_label.configure(image="")
            self._background_image_refs = []
            return
        try:
            source = Image.open(self.background_photo_path).convert("RGB")
            t = THEMES[self.theme_name]
            self._background_image_refs = []
            # App backdrop is deliberately subdued; the user's chosen image stays local.
            if hasattr(self, "root_photo_label"):
                rw, rh = max(1, self.root.winfo_width()), max(1, self.root.winfo_height())
                backdrop = ImageOps.fit(source, (rw, rh), method=Image.Resampling.LANCZOS)
                tint = Image.new("RGB", (rw, rh), t["bg"])
                backdrop = Image.blend(tint, backdrop, self.photo_opacity)
                root_photo = ImageTk.PhotoImage(backdrop)
                self.root_photo_label.configure(image=root_photo)
                self.root_photo_label.lower()
                self._background_image_refs.append(root_photo)
            # Photo-texture panels: use crops blended with theme colors, not transparent widgets.
            for canvas, opacity, bg_color in ((getattr(self, "left_gutter", None), self.photo_opacity, t["gutter"]), (getattr(self, "right_gutter", None), self.photo_opacity, t["gutter"])):
                if canvas is None: continue
                w, h = max(44, canvas.winfo_width()), max(200, canvas.winfo_height())
                crop = ImageOps.fit(source, (w, h), method=Image.Resampling.LANCZOS)
                overlay = Image.new("RGB", (w, h), bg_color)
                blended = Image.blend(overlay, crop, opacity)
                photo = ImageTk.PhotoImage(blended)
                canvas.delete("background-photo")
                canvas.create_image(0, 0, image=photo, anchor="nw", tags="background-photo")
                canvas.tag_lower("background-photo")
                self._background_image_refs.append(photo)
            # Blend the photo's average tone into the writing surface, outline, and app panels.
            sample = source.resize((1, 1), Image.Resampling.LANCZOS).getpixel((0, 0))
            def blend_hex(base_hex, alpha):
                base = tuple(int(base_hex[i:i+2], 16) for i in (1, 3, 5))
                rgb = tuple(round(base[j] * (1-alpha) + sample[j] * alpha) for j in range(3))
                return "#%02x%02x%02x" % rgb
            if hasattr(self, "editor"):
                self.editor.configure(bg=blend_hex(t["paper"], self.editor_photo_opacity))
            if hasattr(self, "outline"):
                color = blend_hex(t["surface"], self.outline_photo_opacity)
                for widget in (self.outline, self.outline_list, self.outline_title, self.outline_hint):
                    try: widget.configure(bg=color)
                    except tk.TclError: pass
            if hasattr(self, "landing_frame"):
                self.landing_frame.configure(bg=blend_hex(t["bg"], self.photo_opacity))
            if hasattr(self, "body"):
                self.body.configure(bg=blend_hex(t["bg"], self.panel_photo_opacity))
        except Exception:
            self._background_image_refs = []

    def _seed_particles(self):
        self.particles=[]
        t=THEMES[self.theme_name]
        if t["kind"]=="none":return
        for _ in range(46):
            self.particles.append({
                "x":random.randint(2,40),"y":random.randint(-850,850),
                "size":(random.choice([1,2,2,3]) if t["kind"]=="firefly" else (random.choice([1,1,2,2]) if t["kind"]=="snow" else random.choice([2,3,4,5]))),"speed":random.uniform(0.6,2.3),
                "drift":random.uniform(-0.7,0.7),"phase":random.random()*6.28,"sway":random.uniform(0.035,0.14),
                "length":random.choice([12,18,24,32,42,54,68]),
                "color":random.choice((['#ff3ca6', '#ff66c4'] if self.theme_name == 'Retro' else t["particles"])),"kind":t["kind"]
            })

    def animate_gutters(self):
        t=THEMES[self.theme_name]
        for canvas in (self.left_gutter,self.right_gutter):
            canvas.delete("particle")
            canvas.configure(bg=t["gutter"])
            height=max(canvas.winfo_height(),300)
            if t["kind"]!="none":
                for p in self.particles:
                    p["y"]+=p["speed"]
                    if p["kind"] == "leaf":
                        p["x"] += math.sin(p["phase"]) * 0.42
                        p["phase"] += p.get("sway", 0.07)
                    elif p["kind"] != "tron":
                        p["x"] += p["drift"] + math.sin(p["phase"]) * 0.12
                        p["phase"] += p.get("sway", 0.07)
                    if p["y"]>height+8:
                        p["y"]=random.randint(-150,-5)
                        if p["kind"] != "tron": p["x"]=random.randint(2,40)
                    x=max(2,min(41,p["x"]));y=p["y"];s=p["size"];c=p["color"]
                    if p["kind"]=="leaf":
                        # Tiny sideways pixel leaf, rotating its silhouette while fluttering downward.
                        flip = math.sin(p["phase"]) > 0
                        if flip:
                            canvas.create_rectangle(x,y,x+s*3,y+s,fill=c,outline="",tags="particle")
                            canvas.create_rectangle(x+s,y-s,x+s*2,y+s*2,fill=c,outline="",tags="particle")
                            canvas.create_rectangle(x+s,y,x+s*2,y+s,fill="#62402c",outline="",tags="particle")
                        else:
                            canvas.create_rectangle(x,y,x+s*2,y+s,fill=c,outline="",tags="particle")
                            canvas.create_rectangle(x+s,y-s,x+s*3,y+s*2,fill=c,outline="",tags="particle")
                            canvas.create_rectangle(x+s*2,y,x+s*3,y+s,fill="#62402c",outline="",tags="particle")
                    elif p["kind"]=="star":
                        # Soft, fuzzy white stars made from a loose cluster of tiny white pixels.
                        canvas.create_rectangle(x-s, y, x+s*2, y+s, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x, y-s, x+s, y+s*2, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x-1, y-1, x+s+1, y+s+1, fill="#ffffff", outline="", tags="particle")
                    elif p["kind"]=="snow":
                        # Small, crisp white pixel snowflakes with a simple six-arm silhouette.
                        puff = max(1, s)
                        canvas.create_rectangle(x+puff, y, x+puff*2, y+puff*4, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x, y+puff, x+puff*4, y+puff*2, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x, y, x+puff, y+puff, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x+puff*3, y, x+puff*4, y+puff, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x, y+puff*2, x+puff, y+puff*3, fill="#ffffff", outline="", tags="particle")
                        canvas.create_rectangle(x+puff*3, y+puff*2, x+puff*4, y+puff*3, fill="#ffffff", outline="", tags="particle")
                    elif p["kind"]=="tron":
                        # Matrix-inspired binary streams: each stream keeps a fixed x-position
                        # and fixed character pattern/length while moving vertically only.
                        bits = p.get("bits")
                        if not bits:
                            bits = "\n".join(random.choice("01") for _ in range(random.randint(5, 13)))
                            p["bits"] = bits
                        chars = bits.splitlines()
                        for i, bit in enumerate(chars):
                            shade = "#ff72c6" if i == 0 else "#e83eaa" if i < 3 else "#a9277d"
                            canvas.create_text(x, y + i * 9, text=bit, anchor="nw",
                                               fill=shade, font=("Consolas", 7, "bold"), tags="particle")
                    else:
                        # Small, soft-looking fireflies: compact pixels with dimmer halos.
                        canvas.create_rectangle(x-s,y-s,x+s*2,y+s*2,fill=c,outline="",tags="particle")
                        canvas.create_rectangle(x,y,x+s,y+s,fill="#fff7b0",outline="",tags="particle")
        self.root.after(70,self.animate_gutters)

    def _writing_dialog(self, title, intro, starter):
        """Small offline writing helper: no network or external AI service used."""
        win = tk.Toplevel(self.root)
        win.title(title); win.transient(self.root); win.grab_set(); win.geometry("510x390")
        t = THEMES[self.theme_name]; win.configure(bg=t["bg"])
        tk.Label(win, text=title, font=("Segoe UI", 15, "bold"), bg=t["bg"], fg=t["accent"]).pack(anchor="w", padx=18, pady=(16,4))
        tk.Label(win, text=intro, wraplength=465, justify="left", bg=t["bg"], fg=t["muted"]).pack(anchor="w", padx=18, pady=(0,10))
        text = tk.Text(win, wrap="word", undo=True, font=("Georgia", 11), bg=t["paper"], fg=t["ink"],
                       insertbackground=t["accent"], relief="flat", padx=12, pady=12, height=10)
        text.pack(fill="both", expand=True, padx=18, pady=(0,12)); text.insert("1.0", starter)
        row = tk.Frame(win, bg=t["bg"]); row.pack(fill="x", padx=18, pady=(0,16))
        def insert_text():
            content=text.get("1.0","end-1c").strip()
            if content:
                self.editor.insert("insert", content + "\n")
                self.editor.focus_set(); self.dirty=True; self._title(); self._refresh_status(); self._refresh_outline()
            win.destroy()
        tk.Button(row, text="Insert into document", command=insert_text, relief="flat", padx=12, pady=7,
                  bg=t["accent"], fg=t["bg"], activebackground=t["muted"], cursor="hand2").pack(side="right")
        tk.Button(row, text="Close", command=win.destroy, relief="flat", padx=12, pady=7,
                  bg=t["surface"], fg=t["ink"], cursor="hand2").pack(side="right", padx=8)

    def writing_prompt(self):
        self._writing_dialog("Idea Spark", "Choose a direction, then make it your own. This helper works fully offline.",
            "A place that remembers everyone who has ever visited it...\n\nWhat small detail makes this place feel real?\nWhat does the main character want today?\nWhat unexpected thing changes their plan?\nWhat question should the reader carry into the next paragraph?")

    def outline_starter(self):
        self._writing_dialog("Story / Essay Blueprint", "A flexible scaffold for fiction, essays, reports, or reflections. Replace the bracketed notes.",
            "# Working Title\n\n## 1. Opening / central question\nStart with a vivid detail, a surprising claim, or the problem to be explored.\n\n## 2. Context\nWhat does the reader need to know?\n\n## 3. Development\n- Main point or turning point one\n- Main point or turning point two\n- Evidence, example, or complication\n\n## 4. Discovery\nWhat changes, becomes clearer, or challenges the first assumption?\n\n## 5. Closing\nLeave the reader with a conclusion, image, or next question.")

    def writer_block(self):
        self._writing_dialog("Gentle Writing Reset", "Don't aim for perfect. Pick one tiny next step and keep moving.",
            "Write one deliberately imperfect sentence about what happens next.\n\nIf you are stuck, try one: \n• Describe the room using one sound, one texture, and one smell.\n• Let a character ask a question nobody wants to answer.\n• State the point in plain language, as if explaining it to a friend.\n• Write the scene or paragraph you are most excited about first.\n\nMy next small step: ")

    def revision_checklist(self):
        self._writing_dialog("Revision Constellation", "Use this as a calm second-pass checklist. You do not need to fix everything at once.",
            "MEANING\n[ ] Is the main idea or purpose clear?\n[ ] Does each section earn its place?\n[ ] Have I supported important claims with examples or evidence?\n\nFLOW\n[ ] Does the opening invite the reader in?\n[ ] Do paragraphs connect naturally?\n[ ] Is the ending satisfying rather than abrupt?\n\nCRAFT\n[ ] Can I replace vague words with precise ones?\n[ ] Have I removed repetition that adds no emphasis?\n[ ] Have I read it aloud for rhythm and clarity?\n\nFINAL PASS\n[ ] Names, dates, and facts checked\n[ ] Spelling and punctuation checked\n[ ] Formatting and headings consistent")

    def _configure_tags(self):
        fam=self.font_family; size=self.font_size
        self.editor.tag_configure("bold",font=(fam,size,"bold"))
        self.editor.tag_configure("italic",font=(fam,size,"italic"))
        self.editor.tag_configure("underline",underline=True)
        for a in ("left","center","right","justify"):self.editor.tag_configure("align_"+a,justify="left" if a=="justify" else a)
        self.editor.tag_configure("search_hit",background="#ffef9c",foreground="#222222")
        self.editor.tag_configure("bullet",lmargin1=26,lmargin2=48)
        self.editor.tag_configure("heading1",font=("Segoe UI",22,"bold"),spacing1=12,spacing3=8)
        self.editor.tag_configure("heading2",font=("Segoe UI",16,"bold"),spacing1=9,spacing3=5)

    def apply_heading(self,tag):
        try:a=self.editor.index("sel.first linestart");b=self.editor.index("sel.last lineend")
        except tk.TclError:a=self.editor.index("insert linestart");b=self.editor.index("insert lineend")
        self.editor.tag_add(tag,a,b);self.dirty=True;self._title();self._refresh_outline()

    def _refresh_outline(self):
        if not hasattr(self,"outline_list"):return
        for child in self.outline_list.winfo_children():child.destroy()
        for line in range(1,int(self.editor.index("end-1c").split(".")[0])+1):
            start=f"{line}.0";end=f"{line}.end";text=self.editor.get(start,end).strip()
            tags=set(self.editor.tag_names(start))
            if not text:continue
            if "heading1" in tags or text.startswith("# "):
                label=text[2:].strip() if text.startswith("# ") else text
                self._outline_button(label,start,1)
            elif "heading2" in tags or text.startswith("## "):
                label=text[3:].strip() if text.startswith("## ") else text
                self._outline_button(label,start,2)
        if not self.outline_list.winfo_children():
            tk.Label(self.outline_list,text="No headings yet",anchor="w",padx=12,pady=8,
                     bg=THEMES[self.theme_name]["surface"],
                     fg=("#fff0d8" if self.theme_name == "Autumn" else THEMES[self.theme_name]["muted"]),
                     font=("Segoe UI",10)).pack(fill="x")

    def _outline_button(self,label,index,level):
        t=THEMES[self.theme_name]
        b=tk.Button(self.outline_list,text=("   " if level==2 else "")+label,anchor="w",
                    relief="flat",bd=0,padx=10,pady=5,bg=t["surface"],fg=("#fff0d8" if self.theme_name == "Autumn" else t["ink"]),
                    activebackground=t["accent"],activeforeground="#ffffff",
                    font=("Segoe UI",9,"bold" if level==1 else "normal"),
                    command=lambda i=index:self._goto(i))
        b.pack(fill="x")

    def _goto(self,index):
        self.editor.mark_set("insert",index);self.editor.see(index);self.editor.focus_set()

    def on_modified(self,_=None):
        if self.loading:self.editor.edit_modified(False);return
        if self.editor.edit_modified():
            self.dirty=True;self._title();self._refresh_status();self._refresh_outline();self.editor.edit_modified(False)

    def _title(self):
        self.root.title(f"{'* ' if self.dirty else ''}{os.path.basename(self.path) if self.path else 'Untitled'} - {APP}")

    def _refresh_status(self):
        content=self.editor.get("1.0","end-1c")
        words=len(re.findall(r"\b[\w'-]+\b",content))
        self.status.configure(text=f"{words} words   •   {len(content)} characters   •   {os.path.basename(self.path) if self.path else 'Unsaved document'}   •   Theme: {self.theme_name}   •   Autosave: 30 sec")

    def selection(self):
        try:return self.editor.index("sel.first"),self.editor.index("sel.last")
        except tk.TclError:return None

    def toggle(self,tag):
        sel=self.selection()
        if not sel:messagebox.showinfo("Format","Select text first.");return
        a,b=sel; ranges=self.editor.tag_ranges(tag);covered=False
        for i in range(0,len(ranges),2):
            if self.editor.compare(ranges[i],"<=",a) and self.editor.compare(ranges[i+1],">=",b):covered=True;break
        (self.editor.tag_remove if covered else self.editor.tag_add)(tag,a,b);self.editor.focus_set()

    def apply_font(self,_=None):
        sel=self.selection()
        if sel:
            family=self.font_box.get();tag="font_"+re.sub(r"\W+","_",family)
            self.editor.tag_configure(tag,font=(family,self._get_size()));self.editor.tag_add(tag,*sel)
    def _get_size(self):
        try:return max(6,min(200,int(self.size_box.get())))
        except Exception:return self.font_size
    def apply_size(self,_=None):
        sel=self.selection()
        if not sel:return
        try:size=max(6,min(200,int(self.size_box.get())))
        except ValueError:messagebox.showerror("Font size","Enter 6–200.");return
        tag=f"size_{size}";self.editor.tag_configure(tag,font=(self.font_box.get() or self.font_family,size));self.editor.tag_add(tag,*sel)

    def align(self,alignment):
        try:a=self.editor.index("sel.first linestart");b=self.editor.index("sel.last lineend")
        except tk.TclError:a=self.editor.index("insert linestart");b=self.editor.index("insert lineend")
        for tag in ("align_left","align_center","align_right","align_justify"):self.editor.tag_remove(tag,a,b)
        self.editor.tag_add("align_"+alignment,a,b)
    def _line_range(self):
        try:return self.editor.index("sel.first linestart"),self.editor.index("sel.last lineend")
        except tk.TclError:return self.editor.index("insert linestart"),self.editor.index("insert lineend")
    def bullets(self):
        a,b=self._line_range();lines=self.editor.get(a,b).splitlines()
        out=[("• "+x if x.strip() and not x.lstrip().startswith("• ") else x) for x in lines]
        self.editor.delete(a,b);self.editor.insert(a,"\n".join(out))
    def insert_page_break(self):self.editor.insert("insert","\n[PAGE BREAK]\n")
    def insert_date(self):
        from datetime import date
        self.editor.insert("insert",date.today().strftime("%B %d, %Y"))
    def insert_table(self):
        rows=simpledialog.askinteger("Insert table","Rows (1–30):",minvalue=1,maxvalue=30,parent=self.root)
        if rows is None:return
        cols=simpledialog.askinteger("Insert table","Columns (1–12):",minvalue=1,maxvalue=12,parent=self.root)
        if cols is None:return
        text=f"[TABLE {rows}x{cols}]\n"+"\n".join("\t".join(f"Cell {r+1},{c+1}" for c in range(cols)) for r in range(rows))+"\n"
        self.editor.insert("insert",text+"\n")
        messagebox.showinfo("Table","Table placeholder inserted. Edit tab-separated cells; saving as DOCX converts it to a Word table.")
    def insert_image(self):
        path=filedialog.askopenfilename(title="Insert picture",filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff"),("All files","*.*")])
        if not path:return
        width=simpledialog.askfloat("Image width","Width in inches (0.5–6.5):",initialvalue=4.5,minvalue=.5,maxvalue=6.5,parent=self.root)
        if width is not None:self.editor.insert("insert",f"\n[IMAGE: {path} | WIDTH: {width}]\n")
    def set_margins(self):
        """Word-style page margin dialog with presets, units, and a live page preview."""
        t = THEMES.get(self.theme_name, THEMES["Retro"])
        win = tk.Toplevel(self.root)
        win.title("Margins | Wordless")
        win.transient(self.root)
        win.grab_set()
        win.resizable(False, False)
        win.configure(bg=t["bg"])
        win.geometry("650x455")

        tk.Label(win, text="PAGE MARGINS", font=("Segoe UI", 15, "bold"),
                 bg=t["bg"], fg=t["accent"]).pack(anchor="w", padx=20, pady=(16, 2))
        tk.Label(win, text="Choose a preset or enter precise values for each edge.",
                 font=("Segoe UI", 9), bg=t["bg"], fg=t["muted"]).pack(anchor="w", padx=20, pady=(0, 12))

        presets = {
            "Normal": (1.0, 1.0, 1.0, 1.0),
            "Narrow": (0.5, 0.5, 0.5, 0.5),
            "Moderate": (0.75, 0.75, 1.0, 1.0),
            "Wide": (1.0, 1.0, 2.0, 2.0),
            "Mirrored": (1.0, 1.0, 1.25, 0.75),
        }
        preset_row = tk.Frame(win, bg=t["bg"]); preset_row.pack(fill="x", padx=20, pady=(0, 12))
        tk.Label(preset_row, text="PRESETS", font=("Segoe UI", 8, "bold"),
                 bg=t["bg"], fg=t["muted"]).pack(side="left", padx=(0, 9))

        content = tk.Frame(win, bg=t["bg"]); content.pack(fill="both", expand=True, padx=20)
        fields = tk.Frame(content, bg=t["surface"], padx=14, pady=12)
        fields.pack(side="left", fill="both", expand=True, padx=(0, 16))
        preview_wrap = tk.Frame(content, bg=t["bg"]); preview_wrap.pack(side="right", fill="y")
        tk.Label(preview_wrap, text="PAGE PREVIEW", font=("Segoe UI", 8, "bold"),
                 bg=t["bg"], fg=t["muted"]).pack(pady=(0, 6))
        canvas = tk.Canvas(preview_wrap, width=185, height=230, bg=t["bg"],
                           highlightthickness=0, bd=0)
        canvas.pack()

        unit = tk.StringVar(value="in")
        last_unit = ["in"]
        mirror_var = tk.BooleanVar(value=self.mirror_margins)
        tk.Label(fields, text="Margins", font=("Segoe UI", 10, "bold"),
                 bg=t["surface"], fg=t["ink"]).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        tk.Label(fields, text="Edge", bg=t["surface"], fg=t["muted"]).grid(row=1, column=0, sticky="w", padx=(0, 14))
        tk.Label(fields, text="Value", bg=t["surface"], fg=t["muted"]).grid(row=1, column=1, sticky="w")
        rows = [("Top", self.margin_top), ("Bottom", self.margin_bottom),
                ("Left", self.margin_left), ("Right", self.margin_right)]
        entries = {}
        for row, (label, value) in enumerate(rows, start=2):
            tk.Label(fields, text=label, bg=t["surface"], fg=t["ink"],
                     font=("Segoe UI", 10)).grid(row=row, column=0, sticky="w", pady=5, padx=(0, 14))
            ent = tk.Entry(fields, width=10, relief="flat", bd=0, justify="right",
                           bg=t["paper"], fg=t["ink"], insertbackground=t["ink"],
                           highlightthickness=1, highlightbackground=t["muted"],
                           highlightcolor=t["accent"])
            ent.grid(row=row, column=1, sticky="w", pady=5, ipady=5)
            ent.insert(0, f"{value:.2f}".rstrip("0").rstrip("."))
            entries[label] = ent
        unit_row = tk.Frame(fields, bg=t["surface"]); unit_row.grid(row=6, column=0, columnspan=3, sticky="w", pady=(10, 0))
        tk.Label(unit_row, text="Units", bg=t["surface"], fg=t["muted"]).pack(side="left", padx=(0, 10))
        def change_unit():
            old, new_unit = last_unit[0], unit.get()
            if old != new_unit:
                factor = 2.54 if new_unit == "cm" else (1 / 2.54)
                for ent in entries.values():
                    try: value = float(ent.get().strip().replace(",", ".")) * factor
                    except ValueError: continue
                    ent.delete(0, "end"); ent.insert(0, f"{value:.2f}".rstrip("0").rstrip("."))
                last_unit[0] = new_unit
            refresh_preview()
        for text, value in [("Inches", "in"), ("Centimeters", "cm")]:
            tk.Radiobutton(unit_row, text=text, variable=unit, value=value,
                           command=change_unit, bg=t["surface"], fg=t["ink"],
                           selectcolor=t["chrome"], activebackground=t["surface"],
                           activeforeground=t["accent"]).pack(side="left", padx=(0, 8))
        tk.Checkbutton(fields, text="Mirror margins for facing pages", variable=mirror_var,
                       bg=t["surface"], fg=t["ink"], selectcolor=t["chrome"],
                       activebackground=t["surface"], activeforeground=t["accent"]).grid(
                           row=7, column=0, columnspan=3, sticky="w", pady=(12, 0))

        def read_values(show_error=False):
            try:
                vals = {k: float(v.get().strip().replace(",", ".")) for k, v in entries.items()}
                if unit.get() == "cm": vals = {k: v / 2.54 for k, v in vals.items()}
                if any(v < 0.25 or v > 2.5 for v in vals.values()):
                    raise ValueError("Margins must be between 0.25 and 2.5 inches (0.64–6.35 cm).")
                if vals["Left"] + vals["Right"] >= self.page_width - 1 or vals["Top"] + vals["Bottom"] >= self.page_height - 1:
                    raise ValueError("Margins leave too little printable space for this page size.")
                return vals
            except ValueError as exc:
                if show_error:
                    messagebox.showerror("Check margins", str(exc) if str(exc) else "Enter a valid number for each margin.", parent=win)
                return None

        def refresh_preview(*_):
            canvas.delete("all")
            vals = read_values()
            if vals is None:
                vals = {"Top": 1, "Bottom": 1, "Left": 1, "Right": 1}
            pw, ph = self.page_width, self.page_height
            scale = min(142 / pw, 190 / ph)
            x0, y0 = (185 - pw * scale) / 2, (230 - ph * scale) / 2
            x1, y1 = x0 + pw * scale, y0 + ph * scale
            canvas.create_rectangle(x0, y0, x1, y1, fill=t["paper"], outline=t["accent"], width=2)
            lx = x0 + vals["Left"] * scale; rx = x1 - vals["Right"] * scale
            ty = y0 + vals["Top"] * scale; by = y1 - vals["Bottom"] * scale
            canvas.create_rectangle(lx, ty, rx, by, outline=t["muted"], dash=(3, 3))
            for n in range(5):
                yy = ty + 10 + n * 10
                if yy < by - 3:
                    canvas.create_line(lx + 5, yy, max(lx + 6, rx - (12 if n == 1 else 0)), yy,
                                       fill=t["accent"] if n == 0 else t["muted"], width=1)
            canvas.create_text(92, 218, text=f"{self.page_width:g} × {self.page_height:g} in page",
                               fill=t["muted"], font=("Segoe UI", 8))

        def apply_preset(name):
            mirror_var.set(name == "Mirrored")
            vals = presets[name]
            for key, val in zip(("Top", "Bottom", "Left", "Right"), vals):
                display = val * 2.54 if unit.get() == "cm" else val
                entries[key].delete(0, "end"); entries[key].insert(0, f"{display:.2f}".rstrip("0").rstrip("."))
            refresh_preview()

        for name in presets:
            tk.Button(preset_row, text=name, command=lambda n=name: apply_preset(n), cursor="hand2",
                      relief="flat", bd=0, padx=9, pady=5, bg=t["surface"], fg=t["ink"],
                      activebackground=t["chrome"], activeforeground=t["accent"]).pack(side="left", padx=(0, 5))
        for ent in entries.values(): ent.bind("<KeyRelease>", refresh_preview)
        refresh_preview()

        footer = tk.Frame(win, bg=t["bg"]); footer.pack(fill="x", padx=20, pady=16)
        tk.Label(footer, text="Changes apply to the next DOCX save.", bg=t["bg"],
                 fg=t["muted"], font=("Segoe UI", 8)).pack(side="left")
        def apply_margins():
            vals = read_values(show_error=True)
            if vals is None: return
            self.margin_top, self.margin_bottom = vals["Top"], vals["Bottom"]
            self.margin_left, self.margin_right = vals["Left"], vals["Right"]
            self.mirror_margins = bool(mirror_var.get())
            self._draw_rulers()
            self.dirty = True
            self._title()
            win.destroy()
        tk.Button(footer, text="Cancel", command=win.destroy, relief="flat", padx=15, pady=7,
                  bg=t["surface"], fg=t["ink"], activebackground=t["chrome"]).pack(side="right", padx=(8, 0))
        tk.Button(footer, text="Apply margins", command=apply_margins, relief="flat", padx=15, pady=7,
                  bg=t["accent"], fg=t["bg"], activebackground=t["muted"],
                  font=("Segoe UI", 9, "bold")).pack(side="right")

    def set_page_size(self):
        choice=simpledialog.askstring("Page size","Enter Letter, A4, or Legal:",initialvalue="Letter",parent=self.root)
        if not choice:return
        sizes={"letter":(8.5,11),"a4":(8.27,11.69),"legal":(8.5,14)}
        if choice.lower() not in sizes:messagebox.showerror("Page size","Choose Letter, A4, or Legal.");return
        self.page_width,self.page_height=sizes[choice.lower()];self._draw_rulers();self.dirty=True;self._title()
    def find(self):
        query=simpledialog.askstring("Find","Find text:",parent=self.root)
        if not query:return
        self.clear_search();start="1.0";hits=[]
        while True:
            pos=self.editor.search(query,start,stopindex="end-1c",nocase=True)
            if not pos:break
            end=f"{pos}+{len(query)}c";self.editor.tag_add("search_hit",pos,end);hits.append(pos);start=end
        if hits:self.editor.mark_set("insert",hits[0]);self.editor.see(hits[0])
        else:messagebox.showinfo("Find","No matches found.")
    def clear_search(self):self.editor.tag_remove("search_hit","1.0","end")
    def select_all(self):self.editor.tag_add("sel","1.0","end-1c");self.editor.mark_set("insert","1.0");return "break"

    def new_doc(self):
        if not self.confirm_discard():return
        self.loading=True;self.editor.delete("1.0","end");self.loading=False;self.path=None;self.dirty=False;self._show_editor();self._title();self._refresh_status();self._refresh_outline()
    def confirm_discard(self):
        if not self.dirty:return True
        answer=messagebox.askyesnocancel("Unsaved changes","Save changes before continuing?")
        if answer is None:return False
        if answer:return self.save()
        return True
    def open_doc(self):
        if not self.confirm_discard(): return
        path=filedialog.askopenfilename(title="Open document",filetypes=[("Word document","*.docx"),("PDF documents (read-only)","*.pdf"),("Text files","*.txt"),("All files","*.*")])
        if not path:return
        self._open_path(path)

    def _open_path(self, path):
        if not os.path.isfile(path):
            messagebox.showwarning("File unavailable", "This file no longer exists on this device.")
            self._refresh_recent_files()
            return
        if path.lower().endswith(".pdf"):
            self.open_pdf(path)
            return
        try:
            self.loading=True;self.editor.delete("1.0","end")
            if path.lower().endswith(".docx"):
                if not DOCX_OK:raise RuntimeError("DOCX support unavailable.")
                doc=Document(path)
                if doc.sections:
                    sec = doc.sections[0]
                    self.page_width = round(sec.page_width.inches, 2)
                    self.page_height = round(sec.page_height.inches, 2)
                    self.margin_top = round(sec.top_margin.inches, 2)
                    self.margin_bottom = round(sec.bottom_margin.inches, 2)
                    self.margin_left = round(sec.left_margin.inches, 2)
                    self.margin_right = round(sec.right_margin.inches, 2)
                    try:
                        self.mirror_margins = doc.settings.element.xpath('./w:mirrorMargins') != []
                    except Exception:
                        self.mirror_margins = False
                for pi,paragraph in enumerate(doc.paragraphs):
                    paragraph_start=self.editor.index("end-1c")
                    for run in paragraph.runs:
                        a=self.editor.index("end-1c");self.editor.insert("end-1c",run.text);b=self.editor.index("end-1c")
                        if run.bold:self.editor.tag_add("bold",a,b)
                        if run.italic:self.editor.tag_add("italic",a,b)
                        if run.underline:self.editor.tag_add("underline",a,b)
                    paragraph_end=self.editor.index("end-1c")
                    style_name=(paragraph.style.name or "").strip().lower()
                    if style_name in ("heading 1", "title"):
                        self.editor.tag_add("heading1", paragraph_start, paragraph_end)
                    elif style_name == "heading 2":
                        self.editor.tag_add("heading2", paragraph_start, paragraph_end)
                    if pi<len(doc.paragraphs)-1:self.editor.insert("end-1c","\n")
            else:
                with open(path,encoding="utf-8-sig") as f:self.editor.insert("1.0",f.read())
            self.path=os.path.abspath(path);self.dirty=False;self.editor.edit_modified(False)
            self._remember_file(self.path);self._show_editor()
        except Exception as e:messagebox.showerror("Open failed",str(e))
        finally:self.loading=False
        self._title();self._refresh_status();self._refresh_outline()

    def save(self):
        if not self.path:return self.save_as()
        return self._save_path(self.path)
    def save_as(self):
        path=filedialog.asksaveasfilename(title="Save document",defaultextension=".docx",filetypes=[("Word document","*.docx"),("Text file","*.txt")])
        if not path:return False
        return self._save_path(path)
    def _save_path(self,path):
        try:
            if path.lower().endswith(".docx"):
                if not DOCX_OK:raise RuntimeError("DOCX support requires python-docx.")
                self._write_docx(path)
            else:
                with open(path,"w",encoding="utf-8",newline="") as f:f.write(self.editor.get("1.0","end-1c"))
            self.path=os.path.abspath(path);self.dirty=False;self.editor.edit_modified(False);self._remember_file(self.path);self._show_editor();self._title();self._refresh_status();return True
        except Exception as e:messagebox.showerror("Save failed",str(e));return False
    def _write_docx(self,path):
        doc=Document();sec=doc.sections[0]
        sec.page_width=Inches(self.page_width);sec.page_height=Inches(self.page_height)
        sec.top_margin=Inches(self.margin_top);sec.bottom_margin=Inches(self.margin_bottom)
        sec.left_margin=Inches(self.margin_left);sec.right_margin=Inches(self.margin_right)
        doc.styles["Normal"].font.name=self.font_family;doc.styles["Normal"].font.size=Pt(self.font_size)
        lines=self.editor.get("1.0","end-1c").split("\n");i=0
        while i<len(lines):
            line=lines[i]
            tm=re.fullmatch(r"\[TABLE (\d+)x(\d+)\]",line.strip())
            if tm:
                rows,cols=int(tm.group(1)),int(tm.group(2));table=doc.add_table(rows=rows,cols=cols);table.style="Table Grid";table.alignment=WD_TABLE_ALIGNMENT.CENTER
                for r in range(rows):
                    values=lines[i+1+r].split("\t") if i+1+r<len(lines) else []
                    for c in range(cols):table.cell(r,c).text=values[c] if c<len(values) else ""
                i+=rows+1;continue
            im=re.fullmatch(r"\[IMAGE: (.+) \| WIDTH: ([0-9.]+)\]",line.strip())
            if im:
                if os.path.isfile(im.group(1)):doc.add_paragraph().add_run().add_picture(im.group(1),width=Inches(float(im.group(2))))
                else:doc.add_paragraph(f"[Image unavailable: {im.group(1)}]")
                i+=1;continue
            if line.strip()=="[PAGE BREAK]":doc.add_page_break();i+=1;continue
            line_tags=set(self.editor.tag_names(f"{i+1}.0")) if line else set()
            p=doc.add_paragraph()
            # Set paragraph style before adding runs, including for empty headings.
            if "heading1" in line_tags:p.style="Heading 1"
            elif "heading2" in line_tags:p.style="Heading 2"
            elif line.startswith("# "):p.style="Heading 1";line=line[2:]
            elif line.startswith("## "):p.style="Heading 2";line=line[3:]
            if self.editor.tag_nextrange("align_center",f"{i+1}.0",f"{i+1}.end"):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            elif self.editor.tag_nextrange("align_right",f"{i+1}.0",f"{i+1}.end"):p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
            j=0
            while j<len(line):
                tags=set(self.editor.tag_names(f"{i+1}.{j}"));k=j+1
                while k<len(line) and set(self.editor.tag_names(f"{i+1}.{k}"))==tags:k+=1
                run=p.add_run(line[j:k])
                if "bold" in tags:run.bold=True
                if "italic" in tags:run.italic=True
                if "underline" in tags:run.underline=True
                for tag in tags:
                    if tag.startswith("font_"):run.font.name=tag[5:].replace("_"," ")
                    elif tag.startswith("size_"):
                        try:run.font.size=Pt(int(tag[5:]))
                        except ValueError:pass
                j=k
            i+=1
        doc.save(path)
    def autosave_tick(self):
        try:
            if self.dirty:
                ext=".docx" if DOCX_OK else ".txt"
                recovery=os.path.join(os.path.expanduser("~"),"Wordless-Recovery"+ext)
                if ext==".docx":self._write_docx(recovery)
                else:
                    with open(recovery,"w",encoding="utf-8") as f:f.write(self.editor.get("1.0","end-1c"))
                self.status.configure(text=f"Local recovery saved: {recovery}")
        except Exception as e:self.status.configure(text=f"Autosave issue: {e}")
        finally:self.root.after(AUTOSAVE_MS,self.autosave_tick)
    def print_doc(self):
        if not DOCX_OK:messagebox.showerror("Print","Printing requires python-docx.");return
        try:
            fd,path=tempfile.mkstemp(prefix="offline_word_print_",suffix=".docx");os.close(fd);self._write_docx(path)
            if sys.platform.startswith("win"):os.startfile(path,"print")
            else:webbrowser.open("file://"+path)
            messagebox.showinfo("Print","Opened the local print handler, if one is configured. You can print from your installed office application.")
        except Exception as e:messagebox.showerror("Print",f"Could not print automatically:\n{e}\nSave as DOCX and print using a local office app.")
    def close(self):
        if self.confirm_discard():self.root.destroy()

def main():
    root=tk.Tk();WordProcessor(root);root.mainloop()
if __name__=="__main__":main()
