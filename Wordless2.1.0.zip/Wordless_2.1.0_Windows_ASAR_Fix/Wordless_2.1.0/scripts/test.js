const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const files=fs.readdirSync('tests').filter(n=>n.endsWith('.test.js')).sort().map(n=>path.join('tests',n));
if(!files.length)throw Error('No tests found');
const r=spawnSync(process.execPath,['--test',...files],{stdio:'inherit'});if(r.error)throw r.error;process.exit(r.status===null?1:r.status);
