/* Three focused release checks. Full regression suite remains npm test. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'..');process.chdir(root);
const checks=[
 ['tests/build-fix.test.js','packaged source verifier checks ASAR content and rejects a stale feature file'],
 ['tests/docx.test.js','DOCX formatted fixture preserves emphasis and explicit break'],
 ['tests/version-210.test.js','history snapshots survive reload and are document isolated']
];
(async()=>{for(const [file,label]of checks){let selected;const filename=path.join(root,file),localRequire=createRequire(filename);function test(name,options,fn){if(name!==label)return;if(typeof options==='function'){fn=options;options={};}if(options?.skip)throw Error('Required build check may not skip: '+label);selected=fn;}
 const sandbox={require:n=>n==='node:test'?test:localRequire(n),__dirname:path.dirname(filename),__filename:filename,process,Buffer,console,setTimeout,clearTimeout};vm.runInNewContext(fs.readFileSync(filename,'utf8'),sandbox,{filename});if(!selected)throw Error('Build check missing: '+label);await selected();console.log('PASS: '+label);}console.log('3 focused build checks passed. Full suite not run.');})().catch(e=>{console.error(e.stack);process.exitCode=1;});
