# Local Windows font rendering only; no assets are downloaded.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$Assets = Join-Path (Split-Path $PSScriptRoot -Parent) 'src\assets'
[IO.Directory]::CreateDirectory($Assets) | Out-Null
$Family = New-Object System.Drawing.FontFamily('Georgia')
if ($Family.Name -ne 'Georgia') { throw 'Georgia is required to match the Wordless logo. Install/enable the Windows Georgia font and rebuild.' }
$Sizes = @(16,24,32,48,64,128,256)
$Images = @()
foreach ($Size in $Sizes) {
    $Hi = 1024
    $Bitmap = New-Object System.Drawing.Bitmap($Hi,$Hi)
    $Graphics = [System.Drawing.Graphics]::FromImage($Bitmap)
    $Graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#231b1d'))
    $Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $Graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $Font = New-Object System.Drawing.Font($Family,760,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
    $Brush = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#e5a16a'))
    $Format = [System.Drawing.StringFormat]::GenericTypographic.Clone()
    $Format.Alignment = [System.Drawing.StringAlignment]::Center
    $Format.LineAlignment = [System.Drawing.StringAlignment]::Center
    $Rect = New-Object System.Drawing.RectangleF(0,0,$Hi,$Hi)
    $Graphics.DrawString('W',$Font,$Brush,$Rect,$Format)
    $Small = New-Object System.Drawing.Bitmap($Size,$Size)
    $G = [System.Drawing.Graphics]::FromImage($Small)
    $G.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $G.DrawImage($Bitmap,0,0,$Size,$Size)
    $Memory = New-Object IO.MemoryStream
    $Small.Save($Memory,[System.Drawing.Imaging.ImageFormat]::Png)
    $Images += ,($Memory.ToArray())
    if ($Size -eq 256) { [IO.File]::WriteAllBytes((Join-Path $Assets 'wordless.png'),$Memory.ToArray()) }
    $Memory.Dispose();$G.Dispose();$Small.Dispose();$Format.Dispose();$Brush.Dispose();$Font.Dispose();$Graphics.Dispose();$Bitmap.Dispose()
}
# Multi-resolution ICO containing PNG-compressed image entries.
$Stream = [IO.File]::Create((Join-Path $Assets 'wordless.ico'))
$Writer = New-Object IO.BinaryWriter($Stream)
try {
    $Writer.Write([uint16]0);$Writer.Write([uint16]1);$Writer.Write([uint16]$Sizes.Count)
    $Offset = 6 + 16 * $Sizes.Count
    for ($i=0;$i -lt $Sizes.Count;$i++) {
        $Dimension = if ($Sizes[$i] -eq 256) { 0 } else { $Sizes[$i] }
        $Writer.Write([byte]$Dimension);$Writer.Write([byte]$Dimension);$Writer.Write([byte]0);$Writer.Write([byte]0)
        $Writer.Write([uint16]1);$Writer.Write([uint16]32);$Writer.Write([uint32]$Images[$i].Length);$Writer.Write([uint32]$Offset)
        $Offset += $Images[$i].Length
    }
    foreach ($Image in $Images) { $Writer.Write([byte[]]$Image) }
} finally { $Writer.Dispose();$Family.Dispose() }
Write-Host 'Generated W app icon in Georgia, matching the text-only logo.'
