/* Relay native command output to the console AND an exact, persistent log.
 * The child is Node (not a shell), so spaces in extracted folder paths are safe. */
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const [label,...args]=process.argv.slice(2);if(!label||!args.length)throw Error('Expected a step label and Node arguments');
const root=path.resolve(__dirname,'..'),log=path.join(root,'Wordless-build-steps.log');
function write(text){fs.appendFileSync(log,text);process.stdout.write(text);}
write(`\n=== ${new Date().toISOString()} : ${label} ===\n`);
const child=spawn(process.execPath,args,{cwd:root,env:process.env,stdio:['inherit','pipe','pipe'],shell:false});
for(const stream of [child.stdout,child.stderr])stream.on('data',buffer=>{fs.appendFileSync(log,buffer);process.stdout.write(buffer);});
child.on('error',error=>{write(`Unable to start step: ${error.stack}\n`);process.exitCode=1;});
child.on('close',(code,signal)=>{const exit=Number.isInteger(code)?code:1;write(`\nStep ${label}: exit ${exit}${signal?' ('+signal+')':''}\n`);process.exitCode=exit;});
