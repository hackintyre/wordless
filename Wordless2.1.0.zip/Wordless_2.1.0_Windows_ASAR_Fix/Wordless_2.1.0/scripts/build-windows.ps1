# Build tools are local to this source directory. Windows PowerShell 5.1+.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $Root
$Log = Join-Path $Root 'Wordless-build.log'
$Started = $false
$Success = $false
$Stage = 'preparing build tools'
$StepLog = Join-Path $Root 'Wordless-build-steps.log'
Set-Content -LiteralPath $StepLog -Value '' -Encoding UTF8
function Invoke-NodeStep {
    param([string]$Label, [string[]]$NodeArguments)
    & $Node (Join-Path $PSScriptRoot 'run-build-step.js') $Label @NodeArguments
    if ($LASTEXITCODE -ne 0) { throw ("Step '{0}' failed (exit {1}). See Wordless-build-steps.log for the exact error." -f $Label, $LASTEXITCODE) }
}
try {
    Start-Transcript -Path $Log -Force | Out-Null
    $Started = $true
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Build on Windows 10/11 x64.' }
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This package targets 64-bit Windows, not 32-bit Windows.' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { throw 'This build kit targets Intel/AMD x64 Windows. ARM64 requires a separate target.' }
    if ($Root.StartsWith('\\')) { throw 'Extract to a local folder such as Documents\Wordless, not a network share.' }
    Write-Host 'Step 1/5: Preparing pinned local build tools...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $Version = '22.21.1'
    $Name = "node-v$Version-win-x64"
    $Tools = Join-Path $Root '.build-tools'
    New-Item -ItemType Directory -Path $Tools -Force | Out-Null
    $Archive = Join-Path $Tools "$Name.zip"
    $Expected = '3c624e9fbe07e3217552ec52a0f84e2bdc2e6ffa7348f3fdfb9fbf8f42e23fcf'
    if (-not (Test-Path -LiteralPath $Archive)) {
        $Temp = "$Archive.download"
        Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/v$Version/$Name.zip" -OutFile $Temp -TimeoutSec 600
        if ((Get-FileHash -LiteralPath $Temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Expected) {
            Remove-Item -LiteralPath $Temp -Force
            throw 'Downloaded Node ZIP did not match its pinned SHA-256. Build stopped.'
        }
        Move-Item -LiteralPath $Temp -Destination $Archive -Force
    }
    if ((Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Expected) {
        throw 'Cached Node ZIP checksum mismatch. Delete .build-tools and retry.'
    }
    $NodeFolder = Join-Path $Tools $Name
    # Re-extract verified tools; do not trust an unrelated system Node installation.
    if (Test-Path -LiteralPath $NodeFolder) { Remove-Item -LiteralPath $NodeFolder -Recurse -Force }
    Expand-Archive -LiteralPath $Archive -DestinationPath $Tools -Force
    $Node = Join-Path $NodeFolder 'node.exe'
    $Npm = Join-Path $NodeFolder 'node_modules\npm\bin\npm-cli.js'
    $env:Path = "$NodeFolder;$env:Path"
    $env:CSC_IDENTITY_AUTO_DISCOVERY = 'false'
    # Do not inherit Electron development switches or download mirrors.
    Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
    Remove-Item Env:ELECTRON_SKIP_BINARY_DOWNLOAD -ErrorAction SilentlyContinue
    Remove-Item Env:ELECTRON_MIRROR -ErrorAction SilentlyContinue
    Remove-Item Env:ELECTRON_BUILDER_BINARIES_MIRROR -ErrorAction SilentlyContinue
    $env:npm_config_registry = 'https://registry.npmjs.org/'
    $env:npm_config_ignore_scripts = 'false'
    $env:npm_config_production = 'false'
    & $Node --version
    if ($LASTEXITCODE -ne 0) { throw 'Local Node failed to start.' }
    $Stage = 'installing dependencies'
    Write-Host 'Step 2/5: Installing build dependencies (first build can take several minutes)...'
    if (Test-Path -LiteralPath (Join-Path $Root 'package-lock.json')) {
        Invoke-NodeStep 'dependencies' @($Npm,'ci','--include=dev','--no-audit','--no-fund')
    } else {
        Invoke-NodeStep 'dependencies' @($Npm,'install','--include=dev','--no-audit','--no-fund')
    }
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check internet access, proxy rules and the log.' }
    $Stage = 'generating Georgia W icon'
    Invoke-NodeStep 'icon' @((Join-Path $PSScriptRoot 'generate-icon.js'))
    if ($LASTEXITCODE -ne 0) { throw 'W icon generation failed.' }
    $Stage = 'checking dependencies, syntax and tests'
    $env:WORDLESS_REQUIRE_DOCX = '1'
    Write-Host 'Step 3/5: Running syntax and document-conversion checks...'
    Invoke-NodeStep 'required-dependencies' @((Join-Path $PSScriptRoot 'require-build-dependencies.js'))
    if ($LASTEXITCODE -ne 0) { throw 'Required document/build packages are missing or failed to load.' }
    Invoke-NodeStep 'syntax' @($Npm,'run','check')
    if ($LASTEXITCODE -ne 0) { throw 'JavaScript syntax checks failed.' }
    Invoke-NodeStep 'tests' @($Npm,'run','test:build')
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed. No release EXE will be produced.' }
    $Stage = 'packaging portable x64 EXE'
    Write-Host 'Step 4/5: Packaging portable Wordless.exe...'
    $Dist = Join-Path $Root 'dist'
    $Built = Join-Path $Dist 'Wordless.exe'
    $Final = Join-Path $Root 'Wordless.exe'
    # Remove stale release outputs so a failed build cannot be mistaken for success.
    if (Test-Path -LiteralPath $Final) { Remove-Item -LiteralPath $Final -Force }
    if (Test-Path -LiteralPath $Dist) { Remove-Item -LiteralPath $Dist -Recurse -Force }
    Invoke-NodeStep 'package' @($Npm,'run','dist')
    if ($LASTEXITCODE -ne 0) { throw 'EXE packaging failed. Close Wordless before rebuilding; see log for details.' }
    if (-not (Test-Path -LiteralPath $Built)) { throw 'Builder returned without creating dist\Wordless.exe.' }
    $Stream = [IO.File]::OpenRead($Built)
    try { if ($Stream.ReadByte() -ne 77 -or $Stream.ReadByte() -ne 90) { throw 'Build output is not a Windows executable.' } }
    finally { $Stream.Dispose() }
    $Stage = 'verifying packaged files'
    Invoke-NodeStep 'verify-package' @((Join-Path $PSScriptRoot 'verify-build.js'))
    Copy-Item -LiteralPath $Built -Destination $Final -Force
    $Hash = (Get-FileHash -LiteralPath $Final -Algorithm SHA256).Hash.ToLowerInvariant()
    Set-Content -LiteralPath (Join-Path $Root 'Wordless.exe.sha256') -Value "$Hash  Wordless.exe" -Encoding ASCII
    Write-Host 'Step 5/5: Complete!' -ForegroundColor Green
    Write-Host "Your portable app: $Final"
    Write-Host 'Launch it and test it before distribution. The EXE has not been code-signed.'
    @{version='2.1.0';success=$true;stage='verified';output=$Final;sha256=$Hash} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $Root 'Wordless-build-status.json') -Encoding UTF8
    $Success = $true
    # Open the folder, but do not automatically launch an untested release.
    try { Start-Process explorer.exe -ArgumentList ('/select,"' + $Final + '"') } catch { Write-Host 'Open this folder to find Wordless.exe.' }
} catch {
    Write-Host ("BUILD FAILED: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host "Failed stage: $Stage"
    Write-Host "Logs: $Log and $StepLog"
    Write-Host 'If no dist folder exists, an earlier tool/dependency/icon/test step stopped the build.'
    Write-Host 'Extract the corrected ZIP into a NEW local folder and retry. Do not reuse an older EXE.'
    Write-Host 'If packaging mentions winCodeSign, symbolic links or blocked downloads, share both logs with support; do not disable security policies.'
    @{version='2.1.0';success=$false;stage=$Stage;error=$_.Exception.Message} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $Root 'Wordless-build-status.json') -Encoding UTF8
} finally {
    if ($Started) { Stop-Transcript | Out-Null }
}
if ($Success) { exit 0 } else { exit 1 }
