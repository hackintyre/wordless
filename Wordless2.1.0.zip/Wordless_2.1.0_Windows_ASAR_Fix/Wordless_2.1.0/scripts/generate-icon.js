const {spawnSync}=require('node:child_process'),path=require('node:path');
if(process.platform!=='win32')throw Error('The Georgia icon must be built on Windows using the local logo font.');
const result=spawnSync('powershell.exe',['-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'generate-icon.ps1')],{stdio:'inherit'});
if(result.error)throw result.error;process.exit(result.status===null?1:result.status);
