# Wordless 2.1.0

- Added bounded, timestamped local version history with formatted preview,
  manual/idle/safety snapshots, retention settings and restore safety capture.
- Added case-sensitive/whole-word/highlight-all search, replacement previews,
  revision guards and grouped native replacement transactions.
- Added exact timestamped backup-before-overwrite with abort-on-backup-failure,
  clearer import/format warnings and rich-text/page-break regression fixtures.
- Added bottom-right focus/typewriter mode without changing paper geometry.
- Added optional launch-time goal question, collapsible session controls,
  visible-workspace timer and checkpointed local statistics.
- Added hierarchical outline rows, collapsible sections and native-file block
  bookmarks; view-only collapse state is omitted from saved/exported content.
- Preserved offline restrictions, Georgia W build icon, landing/document
  retention, colour controls, leaf animation, star timing and batch launcher.

See README.md and validation.txt for limitations and checks actually run.
This archive is source/build kit only, not a precompiled Windows executable.

## 2.1.0 build repair (app version unchanged)
- Reproduced the previously skipped DOCX formatted-fixture failure with the real converters installed.
- Normalized semantic emphasis for DOCX export to retain italics and pass the original test.
- Added direct packaged-source verifier dependency and a generated package lockfile.
- Added persistent native-step logs, explicit failure-stage/status reporting and mandatory conversion tests in release builds.
- Added post-package PE/version/ASAR-source verification before final EXE copy.
- Added regression checks for conversion, build logging, portable configuration and verifier rejection of stale packaged sources.
- Retained all other 2.1.0 runtime sources and the batch launcher unchanged.
- Validation: 53 pass, 0 fail, 0 skip; no native Windows build or GUI execution claimed.
