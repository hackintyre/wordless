const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('wordless',{
historyList:()=>ipcRenderer.invoke('history-list'),historyAdd:(v,label)=>ipcRenderer.invoke('history-add',v,label),historyGet:id=>ipcRenderer.invoke('history-get',id),historySettings:v=>ipcRenderer.invoke('history-settings',v),sessionStats:v=>ipcRenderer.invoke('session-stats',v),
windowControl:action=>ipcRenderer.invoke('window-control',action),recent:()=>ipcRenderer.invoke('recent'),openRecent:file=>ipcRenderer.invoke('open-recent',file),
boot:()=>ipcRenderer.invoke('boot'),newDocument:()=>ipcRenderer.invoke('new'),open:()=>ipcRenderer.invoke('open'),save:(value,as)=>ipcRenderer.invoke('save',value,!!as),dirty:value=>ipcRenderer.invoke('dirty',!!value),autosave:value=>ipcRenderer.invoke('autosave',value),preferences:value=>ipcRenderer.invoke('preferences',value),photo:()=>ipcRenderer.invoke('photo'),pdf:()=>ipcRenderer.invoke('pdf'),print:()=>ipcRenderer.invoke('print'),
onCommand:callback=>ipcRenderer.on('command',(_e,name)=>callback(name)),onPrint:callback=>ipcRenderer.on('request-print',()=>ipcRenderer.send('print-payload',callback()))
});
