/* Browser-only renderer. No Node access and no remote resources. */
'use strict';
const $=id=>document.getElementById(id),api=window.wordless,M=window.WordlessModel;
const editor=$('editor'),paper=$('paper'),scroller=$('scroller');
let settings={layout:M.layout(),theme:'Autumn',paused:false,rulers:false,assistantOpen:false},dirty=false,revision=0,recovery=null,savedRange=null,timer,outlineTimer,prefsTimer;
const scene=new WordlessScene($('scene'),$('zone'));
const themes={Autumn:['#231b1d','#fffaf2','#2d2925','#e5a16a'],Retro:['#120c20','#251a36','#f7edff','#ff65ce'],Snow:['#677584','#ffffff','#293440','#b2d0f0'],Stars:['#080d23','#15203a','#e8edff','#a69bff'],Fireflies:['#0c201e','#132b24','#e5f6df','#b1d488']};
function status(text){$('status').textContent=text;}
function message(title,text){$('messageTitle').textContent=title;$('messageText').textContent=text;if(!$('messageDialog').open)$('messageDialog').showModal();}
async function safe(fn){try{return await fn();}catch(e){status('Operation failed');message('Wordless',e.message||String(e));}}
function documentPlainText(){const copy=editor.cloneNode(true);for(const n of copy.querySelectorAll('br'))n.replaceWith('\n');for(const n of copy.querySelectorAll('p,div,h1,h2,h3,h4,li,blockquote,pre,tr'))n.append('\n');return copy.textContent;}
function snapshot(){const copy=editor.cloneNode(true);for(const br of copy.querySelectorAll('.page-break'))br.removeAttribute('style');return {html:copy.innerHTML,text:editor.innerText,layout:settings.layout};}
function setDirty(value){dirty=value;api.dirty(value).catch(e=>status(e.message));}
function changed(){revision++;setDirty(true);status('Unsaved changes');clearTimeout(timer);timer=setTimeout(()=>api.autosave(snapshot()).then(()=>status('Recovery snapshot saved locally')).catch(e=>status('Autosave failed: '+e.message)),3000);scheduleMetrics();requestAnimationFrame(placeBreaks);}
function scheduleMetrics(){clearTimeout(outlineTimer);outlineTimer=setTimeout(()=>{const text=documentPlainText();$('counts').textContent=`${M.words(text).toLocaleString()} words · ${text.length.toLocaleString()} characters`;updatePageGuides();const fragment=document.createDocumentFragment();for(const heading of Array.from(editor.querySelectorAll('h1,h2,h3,h4')).slice(0,250)){const b=document.createElement('button');b.textContent=heading.textContent||'Untitled heading';b.style.paddingLeft=(Number(heading.tagName[1])-1)*12+8+'px';b.onclick=()=>heading.scrollIntoView({block:'center',behavior:'auto'});fragment.append(b);}$('outline').replaceChildren(fragment);window.WordlessFeatures?.outline();},220);}
function persist(){clearTimeout(prefsTimer);prefsTimer=setTimeout(()=>api.preferences(settings).catch(e=>status(e.message)),500);}
function applyLayout(){settings.layout=M.layout(settings.layout);const g=M.geometry(settings.layout);paper.style.width=g.width+'px';paper.style.minHeight=g.height+'px';paper.style.setProperty('--inset',g.inset+'px');paper.style.setProperty('--bodyHeight',g.bodyHeight+'px');paper.style.setProperty('--sheetHeight',g.height+'px');paper.style.zoom=g.zoom;paper.classList.toggle('guides',g.mode==='pages');drawRuler(g);requestAnimationFrame(placeBreaks);$('ruler').style.width=g.width*g.zoom+'px';$('ruler').classList.toggle('hidden',!settings.rulers);$('paperSize').value=g.size;$('margin').value=g.margin;$('zoom').value=Math.round(g.zoom*100);$('zoomValue').textContent=Math.round(g.zoom*100)+'%';$('mode').value=g.mode;scheduleMetrics();persist();}
function applyTheme(){applyPalette();const t=themes[settings.theme]||themes.Autumn;document.body.style.setProperty('--paper',t[1]);document.body.style.setProperty('--ink',t[2]);document.body.style.setProperty('--accent',t[3]);$('zone').style.backgroundColor=t[0];$('theme').value=settings.theme;scene.theme=settings.theme;scene.paused=settings.paused;$('pause').textContent=settings.paused?'Resume scene':'Pause scene';scene.draw();$('ink').value=t[2];persist();}
function selection(){const s=getSelection();if(s.rangeCount&&editor.contains(s.anchorNode)&&editor.contains(s.focusNode))savedRange=s.getRangeAt(0).cloneRange();}
document.addEventListener('selectionchange',selection);
function restoreSelection(){editor.focus({preventScroll:true});if(savedRange&&editor.contains(savedRange.commonAncestorContainer)){const s=getSelection();s.removeAllRanges();s.addRange(savedRange);}}
function format(action,value=null){restoreSelection();document.execCommand(action,false,value);selection();}
editor.addEventListener('input',changed);
editor.addEventListener('paste',e=>{e.preventDefault();const text=e.clipboardData.getData('text/plain');document.execCommand('insertText',false,text);});
editor.addEventListener('drop',e=>e.preventDefault());
editor.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('Files'))e.preventDefault();});
// Native scrolling bubbles from text, margins, guides and background into one scroller.
// There is deliberately no wheel interception, focus forcing, or scroll-time repagination.
for(const button of document.querySelectorAll('[data-action]')){button.addEventListener('mousedown',e=>e.preventDefault());button.onclick=()=>format(button.dataset.action);}
$('block').onchange=e=>format('formatBlock',e.target.value);$('font').onchange=e=>format('fontName',e.target.value);$('fontSize').onchange=e=>format('fontSize',e.target.value);// Pin the document range BEFORE the native colour control takes focus.
let colorRange=null,colorPointerCapture=false;
function captureColorRange(){selection();colorRange=savedRange?.cloneRange()||null;}
$('ink').addEventListener('pointerdown',()=>{captureColorRange();colorPointerCapture=true;setTimeout(()=>{colorPointerCapture=false;},0);});
$('ink').addEventListener('focus',()=>{if(!colorPointerCapture)captureColorRange();colorPointerCapture=false;});
$('ink').onchange=e=>{
 if(colorRange&&editor.contains(colorRange.commonAncestorContainer))savedRange=colorRange.cloneRange();
 const before=revision;format('foreColor',e.target.value);if(revision===before)changed();
 colorRange=savedRange?.cloneRange()||null;
};
function load(data){window.WordlessFeatures?.beforeLoad();showWorkspace();clearTimeout(timer);editor.innerHTML=data.html||'<p><br></p>';savedRange=null;if(data.layout)settings.layout=M.layout(data.layout);$('filename').textContent=data.name||'Untitled';revision++;setDirty(false);applyLayout();scroller.scrollTop=0;scheduleMetrics();status('Ready');window.WordlessFeatures?.loaded();if(data.warnings?.length)message('Import notes',data.warnings.join('\n'));}
let saveBusy=false;
async function save(as){if(saveBusy)return;saveBusy=true;const at=revision;try{status('Saving…');const r=await api.save(snapshot(),as);if(!r){status('Save cancelled');return;}$('filename').textContent=r.name;if(revision===at)setDirty(false);status(revision===at?'Saved locally':'Saved; newer edits remain unsaved');}finally{saveBusy=false;}}
const commands={new:async()=>{if(dirty)await api.historyAdd(snapshot(),'Before new document');if(await api.newDocument())load({html:'<p><br></p>'});},open:async()=>{if(dirty)await api.historyAdd(snapshot(),'Before open document');const data=await api.open();if(data)load(data);},save:()=>save(false),saveAs:()=>save(true),print:()=>api.print(),pdf:()=>api.pdf(),find:()=>{showWorkspace();selection();if(!$('findDialog').open)$('findDialog').show();$('findText').focus();},pause:()=>{settings.paused=!settings.paused;applyTheme();},rulers:()=>{settings.rulers=!settings.rulers;applyLayout();}};
api.onCommand(name=>safe(()=>commands[name]?.()));api.onPrint(snapshot);
for(const b of document.querySelectorAll('[data-command]'))b.onclick=()=>safe(()=>commands[b.dataset.command]());
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{for(const tab of document.querySelectorAll('[data-tab]'))tab.classList.toggle('active',tab===b);$('home').classList.toggle('hidden',b.dataset.tab!=='home');$('file').classList.toggle('hidden',b.dataset.tab!=='file');};
$('apply').onclick=()=>{settings.layout={...settings.layout,size:$('paperSize').value,margin:Number($('margin').value)};applyLayout();changed();};
$('zoom').oninput=e=>{settings.layout.zoom=+e.target.value/100;applyLayout();};$('mode').onchange=e=>{settings.layout.mode=e.target.value;applyLayout();};$('rulers').onclick=commands.rulers;$('pause').onclick=commands.pause;
$('theme').onchange=e=>{settings.theme=e.target.value;applyTheme();};$('photo').onclick=()=>safe(async()=>{const photo=await api.photo();if(photo)$('zone').style.backgroundImage=`url("${photo}")`;});$('clearPhoto').onclick=()=>{$('zone').style.backgroundImage='none';};
$('findButton').onclick=commands.find;
let findState={term:'',text:'',index:-1};
function findInDocument(direction=1){
 window.WordlessFeatures?.reveal();
 const term=$('findText').value;if(!term){$('findCount').textContent='Enter search text';return;}
 const walker=document.createTreeWalker(editor,NodeFilter.SHOW_TEXT),nodes=[];let node,text='';
 while((node=walker.nextNode())){nodes.push({node,start:text.length,end:text.length+node.textContent.length});text+=node.textContent;}
 const matches=window.WordlessFind.matches(text,term,window.WordlessFeatures?.searchOptions());
 if(!matches.length){$('findCount').textContent='No matches';status('No matches');findState={term,text,index:-1};return;}
 let index;
 if(findState.term===term&&findState.text===text&&findState.index>=0)index=(findState.index+direction+matches.length)%matches.length;
 else{let position=direction<0?text.length:0;
  if(savedRange){const entry=nodes.find(n=>n.node===(direction<0?savedRange.startContainer:savedRange.endContainer));if(entry)position=entry.start+(direction<0?savedRange.startOffset:savedRange.endOffset);}
  index=window.WordlessFind.choose(matches,position,direction);
 }
 const match=matches[index],start=nodes.find(n=>n.end>match.start),end=nodes.find(n=>n.end>=match.end);
 if(!start||!end)return;
 const range=document.createRange();range.setStart(start.node,match.start-start.start);range.setEnd(end.node,match.end-end.start);
 const selection=getSelection();selection.removeAllRanges();selection.addRange(range);savedRange=range.cloneRange();
 // Keep the search panel open so its arrows can be used repeatedly.
 start.node.parentElement.scrollIntoView({block:'center',behavior:'auto'});
 findState={term,text,index};$('findCount').textContent=`${index+1} of ${matches.length}`;status(`Match ${index+1} of ${matches.length}`);
}
$('findNext').onclick=()=>findInDocument(1);
$('findPrevious').onclick=()=>findInDocument(-1);
$('findText').addEventListener('input',()=>{findState.index=-1;$('findCount').textContent='';});
$('findText').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();findInDocument(e.shiftKey?-1:1);}});
$('findDialog').addEventListener('cancel',()=>{restoreSelection();});
$('findClose').onclick=()=>{$('findDialog').close();window.WordlessFeatures?.clearHighlights();restoreSelection();};
document.addEventListener('keydown',e=>{if(e.key==='F3'){e.preventDefault();if(!$('findDialog').open)commands.find();findInDocument(e.shiftKey?-1:1);}});

$('recover').onclick=()=>safe(async()=>{if(!recovery){message('Recovery','No previous recovery snapshot is available.');return;}if(dirty&&!confirm('Replace the current unsaved document with the recovery snapshot?'))return;if(!await api.newDocument())return;load({...recovery,name:'Recovered document'});changed();});
// Selection remains in one native editing root, including offscreen content.
// Chromium provides drag edge scrolling; no custom cross-widget selection offsets.
let dragSelecting=false;editor.addEventListener('pointerdown',e=>{if(e.button===0)dragSelecting=true;});window.addEventListener('pointerup',()=>dragSelecting=false);window.addEventListener('blur',()=>dragSelecting=false);
$('zone').addEventListener('pointermove',e=>{if(!dragSelecting||!(e.buttons&1))return;const r=scroller.getBoundingClientRect();if(e.clientY<r.top+36)scroller.scrollBy(0,-14);else if(e.clientY>r.bottom-36)scroller.scrollBy(0,14);});
window.addEventListener('error',e=>status('Editor error: '+e.message));window.addEventListener('unhandledrejection',e=>status('Operation failed: '+(e.reason?.message||e.reason)));
safe(async()=>{const boot=await api.boot();recovery=boot.recovery;$('greeting').textContent=greetings[boot.greetingIndex%greetings.length];settings={...settings,...boot.prefs,layout:M.layout(boot.prefs.layout)};if(!themes[settings.theme])settings.theme='Autumn';applyLayout();applyTheme();setDirty(false);scheduleMetrics();if(recovery)status('Previous recovery snapshot available in File');$('assistant').open=!!settings.assistantOpen;await showLanding();});

const palettes={Autumn:['#221b18','#30251f','#3a2d25','#f8eada','#c5ad96','#745a43','#231b1d','dark'],Retro:['#120c20','#21142e','#2e1b3e','#f7edff','#c6a2cf','#684475','#120c20','dark'],Snow:['#e9eff5','#f5f8fc','#dce6ef','#243444','#526779','#9bafc1','#677584','light'],Stars:['#080d23','#111b35','#1a2745','#e8edff','#aab8d7','#46567b','#080d23','dark'],Fireflies:['#0a1915','#142a22','#203a2c','#e5f6df','#adca9d','#486846','#0c201e','dark']};
function applyPalette(){const p=palettes[settings.theme]||palettes.Autumn;['bg','surface','surface2','text','muted','border','scene'].forEach((key,i)=>document.body.style.setProperty('--'+key,p[i]));document.body.style.colorScheme=p[7];}
function drawRuler(g){const r=$('ruler');r.replaceChildren();for(let n=0;n<=g.width/12;n++){const tick=document.createElement(n%8?'i':'span');tick.style.left=n*12*g.zoom+'px';if(n%8===0)tick.textContent=n/8;r.append(tick);}r.title=`${g.size}: ${(g.width/96).toFixed(2)} inches wide; ticks are eighths.`;}
let placing=false;function placeBreaks(){if(placing)return;placing=true;try{const g=M.geometry(settings.layout);for(const br of editor.querySelectorAll('.page-break')){br.contentEditable='false';br.style.height='24px';if(g.mode!=='pages')continue;const y=(br.getBoundingClientRect().top-paper.getBoundingClientRect().top)/g.zoom,boundary=Math.ceil((y+1)/g.height)*g.height;br.style.height=Math.max(24,boundary+g.inset-y)+'px';}scheduleMetrics();}finally{placing=false;}}
function insertPageBreak(){showWorkspace();restoreSelection();document.execCommand('insertHTML',false,'<div class="page-break" contenteditable="false" role="separator" aria-label="Page break"></div><p><br></p>');changed();requestAnimationFrame(placeBreaks);}
$('insertBreak').onclick=insertPageBreak;editor.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();insertPageBreak();}});
const questions={'Getting started':['What is one image you cannot get out of your mind?','What would you write if nobody else had to read it?','What can you describe using three senses?','What is the smallest scene you could write in five minutes?','What question are you curious enough to follow?'],Characters:['What does your character want but refuse to admit?','What would make your character change their mind?','Who knows a secret about your character?','What small habit reveals something important about them?'],Plot:['What goes wrong if your character does nothing?','What unexpected visitor could arrive right now?','Which choice would make the next scene harder?','What changes if this scene ends the opposite way?'],Revision:['What is this paragraph trying to do?','Which sentence could you remove without losing meaning?','Where could a concrete detail replace an explanation?','What does the reader need to know next?']};
let promptIndex=0;function nextPrompt(){const a=questions[$('promptType').value];$('writingPrompt').textContent=a[promptIndex++%a.length];}$('nextPrompt').onclick=nextPrompt;$('promptType').onchange=()=>{promptIndex=0;nextPrompt();};nextPrompt();$('assistant').ontoggle=()=>{settings.assistantOpen=$('assistant').open;persist();};
const greetings=['Aloha','Buenos dias','Hello There','Bienvenue Mon Ami','Oi.','Hehe','Ollo?','Welcome Back','Willkommen','Yellow?'];
async function showLanding(){$('landing').classList.remove('hidden');$('workspace').classList.add('hidden');const box=$('recentDocuments');box.replaceChildren();const recent=await api.recent();if(!recent.length)box.textContent='No recent documents yet.';for(const file of recent){const b=document.createElement('button');b.textContent=file.split(/[\\/]/).pop();b.title=file;b.onclick=()=>safe(async()=>{if(dirty)await api.historyAdd(snapshot(),'Before open recent');const data=await api.openRecent(file);if(data)load(data);});box.append(b);}}
function showWorkspace(){$('landing').classList.add('hidden');$('workspace').classList.remove('hidden');scene.resize();}
for(const b of document.querySelectorAll('[data-window]'))b.onclick=()=>api.windowControl(b.dataset.window);

// Navigation only: leave editor DOM, undo history, dirty state, file path and scroll intact.
$('brandHome').addEventListener('mousedown',selection);
$('brandHome').onclick=()=>safe(showLanding);
$('continueWriting').onclick=()=>{showWorkspace();editor.focus({preventScroll:true});restoreSelection();};
document.addEventListener('keydown',e=>{const mod=e.ctrlKey||e.metaKey;let command;if(mod&&!e.altKey){if(e.key.toLowerCase()==='s')command=e.shiftKey?'saveAs':'save';else if(e.key.toLowerCase()==='o')command='open';else if(e.key.toLowerCase()==='n')command='new';else if(e.key.toLowerCase()==='p')command='print';else if(e.key.toLowerCase()==='f')command='find';}if(e.key==='F9')command='rulers';if(e.key==='F8')command='pause';if(command){e.preventDefault();safe(()=>commands[command]());}});

// Tab belongs to the document while the editing root has focus. Ctrl+Tab remains
// available as an explicit keyboard escape to the next toolbar control.
editor.addEventListener('keydown',e=>{
 if(e.key!=='Tab'||e.altKey||e.metaKey||e.isComposing)return;
 if(e.ctrlKey){e.preventDefault();$('block').focus();return;}
 e.preventDefault();document.execCommand('insertText',false,'\t');selection();
});
$('resetInk').addEventListener('mousedown',e=>e.preventDefault());
$('resetInk').onclick=()=>{
 restoreSelection();
 // Apply an inheritable CSS value, not a hard-coded colour, so future theme
 // changes also affect reset text. Other text formatting remains unchanged.
 document.execCommand('styleWithCSS',false,true);
 document.execCommand('foreColor',false,'inherit');
 document.execCommand('styleWithCSS',false,false);
 $('ink').value=(themes[settings.theme]||themes.Autumn)[2];selection();
};
function updatePageGuides(){
 const g=M.geometry(settings.layout),layer=$('pageGuides');
 const count=Math.max(1,Math.ceil((editor.scrollHeight+2*g.inset)/g.height));
 const paged=g.mode==='pages';
 paper.style.minHeight=(paged?count*g.height:g.height)+'px';
 $('pages').textContent=paged?`≈ ${count} page${count===1?'':'s'}`:'Pageless';
 const signature=paged?`${count}:${g.height}`:'off';
 if(layer.dataset.signature===signature)return;
 layer.dataset.signature=signature;layer.replaceChildren();
 if(!paged)return;
 const fragment=document.createDocumentFragment();
 for(let page=1;page<count;page++){
  const line=document.createElement('div');line.className='page-guide-line';
  line.style.top=page*g.height+'px';
  const label=document.createElement('span');label.textContent=`Page ${page+1}`;
  line.append(label);fragment.append(line);
 }
 layer.append(fragment);
}
