/* All scene assets are generated locally. No images, fonts, or network requests. */
window.WordlessScene=class{
constructor(canvas,zone){
 this.canvas=canvas;this.zone=zone;this.ctx=canvas.getContext('2d');this.theme='Autumn';this.paused=false;this.last=0;this.time=0;this.starTime=0;this.lastTheme=this.theme;this.shootingStar=null;this.nextShootingStar=this.shootingInterval();
 this.leafShapes=[
  ['000010000','000111000','001111100','011111110','011111110','111111111','111111111','011111110','011111110','001111100','000111000','000010000','000010000'],
  ['000010000','000111000','000111000','001111100','001111100','011111110','011111110','011111110','001111100','001111100','000111000','000010000','000010000'],
  ['0000001000000','0000011100000','0000011100000','0101011101010','0111111111110','0011111111100','1111111111111','0111111111110','0011111111000','0001111100000','0011101110000','0110000011000','0000001000000','0000001000000']
 ];
 // Outline, shadow, midtone, light, and vein/highlight. Copper, gold, red and living greens.
 this.leafPalettes=[['#71351e','#ac4820','#e57728','#ffa94b','#ffd17a'],['#825021','#bd7925','#e9a632','#ffd264','#fff0a1'],['#642b26','#9f3527','#ce4d29','#f57e3e','#ffbc68'],['#3b4525','#65713a','#8a9b49','#b7be65','#dedb91'],['#294b2c','#426e38','#63934a','#91b75f','#c5d98b'],['#614026','#93602c','#bd8d3c','#d7b55b','#efda92']];
 this.leafSprites=this.leafShapes.map((shape)=>this.leafPalettes.map((palette)=>this.shadeLeaf(shape,palette)));
 this.particles=Array.from({length:65},()=>({x:Math.random(),y:Math.random(),speed:.018+Math.random()*.034,size:5+Math.random()*9,phase:Math.random()*Math.PI*2,kind:Math.random(),period:8+Math.random()*2}));
 new ResizeObserver(()=>this.resize()).observe(zone);this.resize();this.frame=this.frame.bind(this);requestAnimationFrame(this.frame);document.addEventListener('visibilitychange',()=>{this.last=0;});
}
shootingInterval(){return 22+Math.random()*33;}
shadeLeaf(shape,palette){
 const mid=(shape[0].length-1)/2;
 return shape.map((row,y)=>Array.from(row,(v,x)=>{
  if(v!=='1')return null;
  const at=(dx,dy)=>shape[y+dy]?.[x+dx]==='1';
  if(y>=shape.length-2)return palette[0];
  if(x===mid)return palette[4];
  if(!at(-1,0)||!at(1,0)||!at(0,-1)||!at(0,1))return palette[x<mid?1:0];
  if(x<mid&&((y+x)%4===0||x===mid-1))return palette[4];
  return palette[x<mid?3:((x+y)%3===0?1:2)];
 }));
}
resize(){this.w=this.zone.clientWidth;this.h=this.zone.clientHeight;const d=Math.min(devicePixelRatio,2);this.canvas.width=this.w*d;this.canvas.height=this.h*d;this.ctx.setTransform(d,0,0,d,0,0);this.draw();}
frame(ts){
 requestAnimationFrame(this.frame);if(document.hidden){this.last=0;return;}
 if(this.last&&ts-this.last<16)return;
 const dt=this.last?Math.min((ts-this.last)/1000,.06):.016;this.last=ts;
 if(this.lastTheme!==this.theme){this.shootingStar=null;this.nextShootingStar=this.starTime+this.shootingInterval();this.lastTheme=this.theme;}
 if(this.paused||!this.w||!this.h)return;
 this.time+=dt;
 if(this.theme==='Stars'){this.starTime+=dt;this.advanceShootingStar(dt);}
 else for(const p of this.particles){
  // Positive descent all the way past the bottom, then re-enter above the top.
  const drift=this.theme==='Autumn'?.76+.24*Math.sin(this.time*.7+p.phase):1;
  p.y+=p.speed*dt*drift;if(p.y>1.1){p.y=0;p.x=Math.random();}
 }
 this.draw();
}
// Perspective-projected 3-D leaf plane: yaw, pitch and roll continuously,
// rather than abruptly flipping a flat sprite. Local pixels remain shaded.
leafPose(phase){
 const t=this.time;
 return {yaw:Math.sin(t*.91+phase)*1.24,pitch:Math.sin(t*.67+phase*1.7)*.65,
  roll:Math.sin(t*.83+phase)*.58+Math.sin(t*.31+phase)*.22,
  depth:Math.sin(t*.45+phase)*35};
}
leaf(x,y,size,phase,paletteIndex,shapeIndex){
 const c=this.ctx,sprite=this.leafSprites[shapeIndex][paletteIndex],pixel=size>10?2:1;
 const pose=this.leafPose(phase),cy=Math.cos(pose.yaw),sy=Math.sin(pose.yaw),cx=Math.cos(pose.pitch),sx=Math.sin(pose.pitch),cr=Math.cos(pose.roll),sr=Math.sin(pose.roll);
 const project=(u,v)=>{const xx=u*cy,zz=-u*sy,yy=v*cx-zz*sx,z=v*sx+zz*cx+pose.depth,k=240/(240+z);return {x:x+(xx*cr-yy*sr)*k,y:y+(xx*sr+yy*cr)*k};};
 c.save();c.globalAlpha=.86+.14*Math.cos(pose.yaw)*Math.cos(pose.pitch);
 for(let row=0;row<sprite.length;row++)for(let col=0;col<sprite[row].length;col++)if(sprite[row][col]){
  const u=(col-sprite[0].length/2)*pixel,v=(row-sprite.length/2)*pixel;
  const corners=[project(u,v),project(u+pixel+.12,v),project(u+pixel+.12,v+pixel+.12),project(u,v+pixel+.12)];
  c.fillStyle=sprite[row][col];c.beginPath();c.moveTo(corners[0].x,corners[0].y);for(const pt of corners.slice(1))c.lineTo(pt.x,pt.y);c.closePath();c.fill();
 }
 c.restore();
}
starBrightness(p){const wave=.5+.5*Math.sin(this.starTime*Math.PI*2/p.period+p.phase);return .16+.84*wave*wave;}
skyRegions(){
 const paper=this.zone.querySelector?.('#paper');
 if(!paper||!this.zone.getBoundingClientRect)return [];
 const z=this.zone.getBoundingClientRect(),r=paper.getBoundingClientRect();
 const left=Math.max(0,Math.min(this.w,r.left-z.left-8)),right=Math.max(0,Math.min(this.w,r.right-z.left+8));
 return [{x:0,width:left},{x:right,width:this.w-right}].filter(r=>r.width>=36);
}
advanceShootingStar(dt){
 if(this.shootingStar){this.shootingStar.age+=dt;if(this.shootingStar.age>=this.shootingStar.duration)this.shootingStar=null;}
 if(this.starTime<this.nextShootingStar)return;
 // Schedule even if the paper fills the viewport: never queue a burst.
 this.nextShootingStar=this.starTime+this.shootingInterval();
 const regions=this.skyRegions();if(!regions.length||this.h<80)return;
 const region=regions[Math.floor(Math.random()*regions.length)],width=region.width;
 const distance=Math.min(75+Math.random()*65,width-20),length=Math.min(45,width*.26),direction=Math.random()<.5?1:-1;
 const travel=Math.max(10,distance-length),margin=8;
 const x=direction>0?region.x+margin+length:region.x+width-margin-length;
 this.shootingStar={region,x,y:12+Math.random()*Math.max(1,this.h-110),dx:direction*travel,dy:25+Math.random()*35,length,duration:.22+Math.random()*.12,age:0};
}
drawShootingStar(){
 const s=this.shootingStar;if(!s)return;const c=this.ctx,t=Math.min(1,s.age/s.duration),x=s.x+s.dx*t,y=s.y+s.dy*t;
 // Re-evaluate the exposed margins so resizing/scrolling cannot put a trail over paper.
 c.save();c.beginPath();for(const region of this.skyRegions())c.rect(region.x,0,region.width,this.h);c.clip();
 c.globalAlpha=Math.sin(Math.PI*t)*.95;
 const norm=Math.hypot(s.dx,s.dy),tx=x-s.dx/norm*s.length,ty=y-s.dy/norm*s.length;
 const gradient=c.createLinearGradient(tx,ty,x,y);gradient.addColorStop(0,'#b8ceff00');gradient.addColorStop(.65,'#b8ceff88');gradient.addColorStop(1,'#ffffff');
 c.strokeStyle=gradient;c.lineWidth=1.5;c.beginPath();c.moveTo(tx,ty);c.lineTo(x,y);c.stroke();
 c.fillStyle='#ffffff';c.beginPath();c.arc(x,y,1.4,0,Math.PI*2);c.fill();c.restore();
}
draw(){
 const c=this.ctx,w=this.w,h=this.h;c.clearRect(0,0,w,h);
 for(const [i,p] of this.particles.entries()){
  const x=this.theme==='Stars'?p.x*w:p.x*w+Math.sin(this.time*.65+p.phase)*(this.theme==='Autumn'?32+p.size*2:17)+(this.theme==='Autumn'?Math.sin(this.time*1.7+p.phase)*9:0),y=p.y*(h+50)-25;
  if(this.theme==='Retro'){c.fillStyle='#ff59c8';c.font='14px monospace';for(let j=0;j<9;j++){c.globalAlpha=(1-j/10)*.65;c.fillText((i+j)%3?'1':'0',p.x*w,y-j*16);}c.globalAlpha=1;}
  else if(this.theme==='Autumn')this.leaf(x,y,p.size,p.phase,i%this.leafPalettes.length,Math.min(2,Math.floor(p.kind*3)));
  else{
   const star=this.theme==='Stars',fire=this.theme==='Fireflies',sy=star?p.y*h:y;
   c.globalAlpha=star?this.starBrightness(p):fire?.25+.65*Math.abs(Math.sin(this.time+p.phase)):.3+p.kind*.65;
   c.fillStyle=fire?'#d5ff8a':'#fff';c.beginPath();c.arc(x,sy,star?1+p.kind:fire?2:p.size/4,0,Math.PI*2);c.fill();
   if(star&&p.kind>.82){
    const gradient=c.createRadialGradient(x,sy,0,x,sy,8);gradient.addColorStop(0,'#eff3ff');gradient.addColorStop(.25,'#bdcaff99');gradient.addColorStop(1,'#bdcaff00');
    c.fillStyle=gradient;c.fillRect(x-8,sy-8,16,16);c.fillRect(x-8,sy-.65,16,1.3);c.fillRect(x-.65,sy-8,1.3,16);
   }
   c.globalAlpha=1;
  }
 }
 if(this.theme==='Stars')this.drawShootingStar();
}
};
