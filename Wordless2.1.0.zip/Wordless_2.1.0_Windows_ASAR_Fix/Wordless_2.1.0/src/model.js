(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.WordlessModel=factory();})(globalThis,()=>{
'use strict';
const sizes={Letter:[816,1056],A4:[793.7,1122.5],Legal:[816,1344]};
function layout(value={}){const size=Object.hasOwn(sizes,value.size)?value.size:'Letter';const margin=Number.isFinite(+value.margin)?Math.max(.25,Math.min(2,+value.margin)):1;const zoom=Number.isFinite(+value.zoom)?Math.max(.5,Math.min(1.75,+value.zoom)):1;return {size,margin,zoom,mode:value.mode==='pageless'?'pageless':'pages'};}
function geometry(value){const l=layout(value),[width,height]=sizes[l.size];return {...l,width,height,inset:l.margin*96,bodyHeight:height-l.margin*192};}
function words(text){return (text.trim().match(/\S+/gu)||[]).length;}
function pageEstimate(height,value){const g=geometry(value);return Math.max(1,Math.ceil(Math.max(0,height)/g.bodyHeight));}
return {layout,geometry,words,pageEstimate,sizes};
});
