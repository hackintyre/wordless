const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
function limits(v={}){const n=(x,d,a,b)=>Number.isFinite(+x)?Math.max(a,Math.min(b,Math.floor(+x))):d;return {days:n(v.days,30,1,365),count:n(v.count,50,2,500),mb:n(v.mb,64,8,512)};}
class HistoryStore{
 constructor(file){this.file=file;}
 async read(){try{return JSON.parse(await fs.readFile(this.file,'utf8'));}catch(e){if(e.code==='ENOENT')return {settings:limits(),items:[]};throw e;}}
 prune(db){db.settings=limits(db.settings);db.items=db.items.filter(i=>i.at>=Date.now()-db.settings.days*86400000).sort((a,b)=>b.at-a.at);const counts=new Map();db.items=db.items.filter(i=>{const n=(counts.get(i.doc)||0)+1;counts.set(i.doc,n);return n<=db.settings.count;});while(Buffer.byteLength(JSON.stringify(db))>db.settings.mb*1024*1024&&db.items.length)db.items.pop();return db;}
 async write(db){await fs.mkdir(path.dirname(this.file),{recursive:true});const tmp=this.file+'.tmp';await fs.writeFile(tmp,JSON.stringify(db));await fs.rename(tmp,this.file);}
 async list(doc){const db=this.prune(await this.read());await this.write(db);return {settings:db.settings,bytes:Buffer.byteLength(JSON.stringify(db)),items:db.items.filter(i=>i.doc===doc).map(({html,text,layout,...i})=>i)};}
 async rekey(from,to){if(from===to)return;const db=await this.read();if(from.startsWith('file:')){const copies=db.items.filter(i=>i.doc===from).map(i=>({...i,id:crypto.randomUUID(),doc:to}));db.items.unshift(...copies);}else for(const i of db.items)if(i.doc===from)i.doc=to;await this.write(this.prune(db));}
 async configure(v){const db=await this.read();db.settings=limits(v);await this.write(this.prune(db));return db.settings;}
 async add(doc,value,label='Snapshot'){const db=await this.read(),item={id:crypto.randomUUID(),doc,at:Date.now(),label:String(label).slice(0,100),...value};if(Buffer.byteLength(JSON.stringify(item))>limits(db.settings).mb*1024*1024-4096)throw Error('Snapshot exceeds the history storage limit; increase the limit before proceeding.');db.items.unshift(item);await this.write(this.prune(db));return item.id;}
 async get(doc,id){const db=await this.read(),item=db.items.find(i=>i.doc===doc&&i.id===id);if(!item)throw Error('Snapshot is no longer available.');return item;}
}
async function backupAndWrite(file,data,atomic){try{await fs.copyFile(file,file+'.wordless-backup-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(3).toString('hex'));}catch(e){if(e.code!=='ENOENT')throw Error('Backup failed; original was not overwritten: '+e.message);}await atomic(file,data);}
module.exports={HistoryStore,limits,backupAndWrite};
