/* Pure text-index lookup, local only. Regex preserves original Unicode offsets. */
(function(root){
 const api={matches(text,term,options={}){if(!term)return [];const escaped=term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const re=new RegExp(escaped,options.caseSensitive?'g':'gi'),out=[];let m;while((m=re.exec(text))){const word=c=>!!c&&/[\p{L}\p{M}\p{N}_]/u.test(c);if(!options.wholeWord||(!word(Array.from(text.slice(0,m.index)).pop())&&!word(Array.from(text.slice(m.index+m[0].length))[0])))out.push({start:m.index,end:m.index+m[0].length});}return out;},
 choose(matches,position,direction){if(!matches.length)return -1;if(direction<0){for(let i=matches.length-1;i>=0;i--)if(matches[i].start<position)return i;return matches.length-1;}const i=matches.findIndex(m=>m.start>=position);return i<0?0:i;}};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.WordlessFind=api;
})(typeof window!=='undefined'?window:globalThis);
