const JSZip=require('jszip');
const {DOMParser,XMLSerializer}=require('@xmldom/xmldom');
const crypto=require('node:crypto');
const W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const breakHTML='<div class="page-break" contenteditable="false" role="separator" aria-label="Page break"></div>';
function parse(xml){if(/<!DOCTYPE/i.test(xml))throw Error('DOCTYPE is not supported');return new DOMParser().parseFromString(xml,'application/xml');}
const elements=(doc,name)=>Array.from(doc.getElementsByTagNameNS(W,name));
async function importBreaks(buffer,convert){const zip=await JSZip.loadAsync(buffer),entry=zip.file('word/document.xml');if(!entry)throw Error('Invalid DOCX');if(entry._data?.uncompressedSize>64*1024*1024)throw Error('DOCX content too large');const doc=parse(await entry.async('string')),marker='WORDLESSBREAK'+crypto.randomBytes(18).toString('hex');
const text=()=>{const n=doc.createElementNS(W,'w:t');n.appendChild(doc.createTextNode(marker));return n;};
for(const br of elements(doc,'br'))if(br.getAttributeNS(W,'type')==='page')br.parentNode.replaceChild(text(),br);
for(const before of elements(doc,'pageBreakBefore')){if(['0','false','off'].includes(before.getAttributeNS(W,'val')))continue;const props=before.parentNode,para=props.parentNode,run=doc.createElementNS(W,'w:r');run.appendChild(text());para.insertBefore(run,props.nextSibling);props.removeChild(before);}
zip.file('word/document.xml',new XMLSerializer().serializeToString(doc));const result=await convert({buffer:await zip.generateAsync({type:'nodebuffer'})},{externalFileAccess:false});
result.value=result.value.replace(/<p([^>]*)>([\s\S]*?)<\/p>/g,(whole,attrs,body)=>body.includes(marker)?body.split(marker).map(s=>'<p'+attrs+'>'+s+'</p>').join(breakHTML):whole).split(marker).join(breakHTML);return result;}
async function exportBreaks(html,options,convert){const marker='WORDLESSBREAK'+crypto.randomBytes(18).toString('hex');// html-to-docx 1.8.0 handles <i> but drops semantic <em> italics.
// Normalize equivalent tags at the export boundary; native content stays intact.
const compatible=html.replace(/<(\/?)em(?=[\s>])/gi,'<$1i');const converted=compatible.replace(/<div\b[^>]*class="page-break"[^>]*>\s*<\/div>/gi,'<p>'+marker+'</p>');const buffer=await convert('<!doctype html><html><body>'+converted+'</body></html>',null,options),zip=await JSZip.loadAsync(buffer),doc=parse(await zip.file('word/document.xml').async('string'));
for(const t of elements(doc,'t'))if(t.textContent===marker){const br=doc.createElementNS(W,'w:br');br.setAttributeNS(W,'w:type','page');t.parentNode.replaceChild(br,t);}
zip.file('word/document.xml',new XMLSerializer().serializeToString(doc));return zip.generateAsync({type:'nodebuffer'});}
module.exports={importBreaks,exportBreaks,breakHTML};
