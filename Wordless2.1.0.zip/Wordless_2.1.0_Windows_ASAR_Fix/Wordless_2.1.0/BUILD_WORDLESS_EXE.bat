@echo off
setlocal
cd /d "%~dp0"
title Wordless - Create portable EXE
echo.
echo WORDLESS - CREATE THE PORTABLE WINDOWS APP
echo This build needs internet. The finished Wordless.exe runs offline.
echo No administrator access or manual Node installation is normally needed.
echo.
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Windows PowerShell is unavailable or blocked on this computer.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-windows.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo BUILD FAILED. Please share Wordless-build.log from this folder.
  echo Do not distribute an older EXE as if it were this build.
) else (
  echo SUCCESS. Wordless.exe is now beside this batch file.
  echo Copy only that EXE to other compatible Windows computers.
)
pause
exit /b %RESULT%
