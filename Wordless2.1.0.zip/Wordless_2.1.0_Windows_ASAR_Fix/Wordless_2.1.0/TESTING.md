# Windows 2.1.0 acceptance checklist

Work on copies. Build with BUILD_WORDLESS_EXE.bat and use the NEW EXE.
The sandbox automated checks are not a substitute for these GUI tests.

## History and I/O
- Open tests/fixtures/formatted-breaks.wordless. Verify emphasis, colour,
  both headings, explicit page break and Return here bookmark.
- Snapshot, edit, snapshot again; preview both versions. Restore the older one:
  verify unsaved status, original file association and pre-restore snapshot.
- Close/reopen the app and same path; verify versions remain accessible.
- Start an untitled document, snapshot it, save; verify history follows first
  save. Save As another path; verify old and new paths retain histories.
- Configure 2 snapshots/document and verify oldest pruning after confirmation.
  Test days/MB limits on disposable data, including a too-large snapshot.
- Save over native, TXT and DOCX files. Verify timestamped sibling backups
  contain the EXACT pre-save bytes. Simulate a non-writable backup destination;
  saving must fail without overwriting the source. No stale EXE on failed build.
- Verify DOCX/TXT and sanitized-native import warnings are understandable.

## Find and Replace
- Repeated Find up/down and wraparound, Enter/Shift+Enter, F3/Shift+F3.
- Mixed case, whole words, punctuation, accented Unicode and combining marks.
- Highlight-all on/off; verify highlighted marks never enter saved HTML.
- Preview/cancel replacement; verify document unchanged. Preview and replace
  a single match, then Replace All and press Undo ONCE for the full group.
- Repeat across bold/italic/coloured runs, paragraphs and near explicit breaks.
  Check formatting outside the replaced ranges and bookmark preservation.
- Edit after a preview; Apply must refuse and request a fresh preview.
- With a section folded, Find must reveal/navigate to a matching hidden line.

## Focus and sessions
- Toggle bottom-right focus/typewriter; verify ribbon/sidebar hide, paper
  size/margins stay fixed and caret follows typing at various zoom settings.
- Toggle back; all original controls and unsaved content remain intact.
- New/Open triggers optional goal question. Not now collapses; Yes reveals
  target/timer controls. Start, reach goal, reset, switch documents.
- Verify timer pauses on landing/minimize and statistics survive app restart.
  Repeated checkpoints must not double-count seconds, words or sessions.
  Verify disclosure of up-to-15-second crash checkpoint loss.

## Outline/bookmarks and preserved functionality
- Create H1/H2/H3/H4; inspect hierarchy, collapse nested sections, expand and
  navigate. Insert/reorder headings; folding must not attach to unrelated ones.
- Add/rename by re-bookmarking/remove block bookmarks, save/reopen native file.
- Verify collapsed text remains in counts, history, native save, DOCX/TXT and
  print; collapse itself is view-only and does not persist.
- Select text, colour it, reset, Undo; save/reopen and repeat at high DPI.
- Logo > landing > Continue writing must preserve unsaved text and selection.
- Check Georgia W EXE/window icons, Autumn 3-D flutter and stationary star
  glimmer/shooting-star timing after resize, pause/resume and minimize/restore.
- Disconnect network after build; writing/history/search/stats/save must work.

## Automated checks
node scripts/check.js
node scripts/test.js

DOCX fixtures/integration checks execute once build dependencies are installed.
Check validation.txt for exactly what was executed in the preparation sandbox.

## Corrected build acceptance
- Use a NEW extracted folder and run BUILD_WORDLESS_EXE.bat. Confirm all DOCX tests execute, not skip.
- Confirm dist/Wordless.exe and dist/win-unpacked/Wordless.exe exist and the verified portable copy appears beside the batch file.
- Inspect dist/Wordless-build-verification.json and Wordless-build-status.json (success: true).
- Run the NEW Wordless.exe and perform the feature checklist above. Packaging/header/source validation is not a GUI smoke test.
- If there is no dist, inspect the recorded stage and raw output in Wordless-build-steps.log; an earlier failure deliberately stops packaging.
- Preserve both build logs when requesting help. Dependency download or winCodeSign/resource-editing policy failures require the real local logs to diagnose.
