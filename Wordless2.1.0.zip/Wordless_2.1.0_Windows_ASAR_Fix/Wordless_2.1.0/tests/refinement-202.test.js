const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const F=require('../src/find'),read=n=>fs.readFileSync(n,'utf8');
test('literal search escapes regex characters and keeps Unicode source offsets',()=>{
 assert.deepEqual(F.matches('İ x [a] x [a]','[a]'),[{start:4,end:7},{start:10,end:13}]);
 assert.deepEqual(F.matches('a.* A.*','a.*'),[{start:0,end:3},{start:4,end:7}]);
 assert.deepEqual(F.matches('word',''),[]);
});
test('find direction wraps and respects initial caret position',()=>{
 const m=F.matches('one ONE one','one');assert.equal(F.choose(m,4,1),1);assert.equal(F.choose(m,4,-1),0);assert.equal(F.choose(m,99,1),0);assert.equal(F.choose(m,0,-1),2);assert.equal(F.choose([],0,1),-1);
});
test('find UI navigates next and previous repeatedly without closing panel, across text nodes',()=>{
 const nodes=['Alpha ','be','ta Alpha beta'].map(text=>({textContent:text,parentElement:{scrollIntoView(){}}}));
 const els=Object.fromEntries(['findNext','findPrevious','findText','findDialog','findCount','findClose'].map(id=>[id,{value:'beta',addEventListener(){}}]));
 let selected;
 const context={window:{WordlessFind:F},editor:{},NodeFilter:{SHOW_TEXT:4},savedRange:null,$:id=>els[id],status(){},restoreSelection(){},commands:{find(){}},getSelection:()=>({removeAllRanges(){},addRange(r){selected=r;}}),document:{addEventListener(){},createTreeWalker(){let i=0;return {nextNode:()=>nodes[i++]||null};},createRange(){return {setStart(n,o){this.startContainer=n;this.startOffset=o;},setEnd(n,o){this.endContainer=n;this.endOffset=o;},cloneRange(){return {...this};}};}}};
 vm.createContext(context);const source=read('src/renderer.js');vm.runInContext(source.slice(source.indexOf('let findState='),source.indexOf("$('recover').onclick")),context);
 els.findNext.onclick();assert.equal(els.findCount.textContent,'1 of 2');assert.equal(selected.startContainer,nodes[1]);assert.equal(selected.endContainer,nodes[2]);assert.equal(selected.endOffset,2);
 els.findNext.onclick();assert.equal(els.findCount.textContent,'2 of 2');els.findNext.onclick();assert.equal(els.findCount.textContent,'1 of 2');els.findPrevious.onclick();assert.equal(els.findCount.textContent,'2 of 2');
 els.findText.value='no match';els.findNext.onclick();assert.equal(els.findCount.textContent,'No matches');
});
test('colour picker restores captured selected range even after focus changes selection',()=>{
 const handlers={},range={token:'selected words',commonAncestorContainer:{},cloneRange(){return {...this};}};
 let applied,dirty=false;const control={addEventListener(n,fn){handlers[n]=fn;}};
 const context={$:()=>control,savedRange:range,selection(){},editor:{contains:()=>true},setTimeout(){},revision:7,changed(){dirty=true;},format(action,value){applied={action,value,range:context.savedRange};}};
 vm.createContext(context);const source=read('src/renderer.js'),start=source.indexOf('let colorRange=null,'),end=source.indexOf('\n',source.indexOf('colorRange=savedRange?.cloneRange()||null;\n};',start)+50);
 const block=source.slice(start,source.indexOf('\n};',source.indexOf("$('ink').onchange",start))+4);vm.runInContext(block,context);
 handlers.pointerdown();context.savedRange={token:'collapsed caret'};handlers.focus();control.onchange({target:{value:'#cc3344'}});
 assert.equal(applied.range.token,'selected words');assert.equal(applied.action,'foreColor');assert.equal(applied.value,'#cc3344');assert.equal(dirty,true);
});
test('leaf pose changes continuously in all three rotational axes',()=>{
 const context={window:{}};vm.createContext(context);vm.runInContext(read('src/scene.js'),context);
 const scene=Object.create(context.window.WordlessScene.prototype);scene.time=2;const a=scene.leafPose(.7);scene.time=2.001;const b=scene.leafPose(.7);
 for(const axis of ['yaw','pitch','roll','depth']){assert.notEqual(a[axis],b[axis]);assert.ok(Math.abs(a[axis]-b[axis])<.1);}
 assert.match(read('src/scene.js'),/240\/\(240\+z\)/);assert.match(read('src/scene.js'),/if\(p.y>1.1\)/);
});
test('W icon uses Georgia and is wired to Windows EXE and window',()=>{
 const pkg=JSON.parse(read('package.json'));assert.equal(pkg.version,'2.1.0');assert.equal(pkg.build.win.icon,'src/assets/wordless.ico');assert.equal(pkg.build.win.signAndEditExecutable,true);
 assert.match(read('scripts/generate-icon.ps1'),/FontFamily\('Georgia'\)/);assert.match(read('scripts/generate-icon.ps1'),/DrawString\('W'/);assert.match(read('src/main.js'),/icon:path.join\(__dirname,'assets','wordless.ico'\)/);assert.match(pkg.scripts.predist,/generate-icon/);
});
