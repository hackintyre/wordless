const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('src/scene.js','utf8'),renderer=fs.readFileSync('src/renderer.js','utf8');
function scene(){
 const calls=[],ctx=new Proxy({},{get:(_,k)=>['createRadialGradient','createLinearGradient'].includes(k)?()=>({addColorStop(){}}):(...args)=>calls.push([k,...args]),set:()=>true});
 const document={hidden:false,addEventListener(){}};
 const zone={clientWidth:1200,clientHeight:800,querySelector:()=>({getBoundingClientRect:()=>({left:200,right:1000})}),getBoundingClientRect:()=>({left:0})};
 const context={window:{},Math,devicePixelRatio:1,requestAnimationFrame(){},ResizeObserver:class{observe(){}},document};
 vm.createContext(context);vm.runInContext(source,context);
 return {s:new context.window.WordlessScene({getContext:()=>ctx},zone),calls,zone,document};
}
test('release metadata and text-only accessible landing button',()=>{
 assert.equal(JSON.parse(fs.readFileSync('package.json')).version,'2.1.0');
 assert.match(fs.readFileSync('src/index.html','utf8'),/<button id="brandHome"[^>]+>wordless<\/button>/);
 assert.match(renderer,/\$\('brandHome'\)\.onclick=\(\)=>safe\(showLanding\)/);
 assert.ok(fs.existsSync('BUILD_WORDLESS_EXE.bat'));
});
test('landing navigation keeps dirty document, selection, history and scroll untouched',async()=>{
 const elements=Object.fromEntries(['landing','workspace','recentDocuments'].map(id=>[id,{classList:{remove(){},add(){}},replaceChildren(){},textContent:''}]));
 const context={$:id=>elements[id],api:{recent:async()=>[]},editor:{innerHTML:'<p>Unsaved draft</p>'},dirty:true,revision:9,savedRange:{token:1},scroller:{scrollTop:431}};
 vm.createContext(context);vm.runInContext(renderer.match(/async function showLanding\(\).*\n/)[0],context);await context.showLanding();
 assert.equal(context.editor.innerHTML,'<p>Unsaved draft</p>');assert.equal(context.dirty,true);assert.equal(context.revision,9);assert.equal(context.savedRange.token,1);assert.equal(context.scroller.scrollTop,431);
 assert.match(renderer,/editor\.focus\(\{preventScroll:true\}\);restoreSelection\(\)/);
});
test('three distinct leaf silhouettes, six palettes, multi-tone sprites',()=>{
 const {s}=scene();assert.equal(s.leafShapes.length,3);assert.equal(s.leafPalettes.length,6);
 assert.equal(new Set(s.leafShapes.map(a=>a.join(''))).size,3);
 for(const variants of s.leafSprites)for(const sprite of variants)assert.ok(new Set(sprite.flat().filter(Boolean)).size>=4);
});
test('stationary stars have noticeable 8–10 second periodic glimmer',()=>{
 const {s}=scene();s.theme='Stars';const positions=s.particles.map(p=>[p.x,p.y]);
 for(const p of s.particles){assert.ok(p.period>=8&&p.period<=10);let low=1,high=0;for(let i=0;i<=100;i++){s.starTime=i*p.period/100;const b=s.starBrightness(p);low=Math.min(low,b);high=Math.max(high,b);}assert.ok(high-low>.8);s.starTime=1.3;const a=s.starBrightness(p);s.starTime+=p.period;assert.ok(Math.abs(a-s.starBrightness(p))<1e-10);}
 s.frame(1000);s.frame(1040);assert.deepEqual(s.particles.map(p=>[p.x,p.y]),positions);
 assert.match(source,/createRadialGradient/);assert.match(source,/sy-8,1\.3,16/);
});
test('shooting stars obey duration, spacing, side-sky clipping and expiry',()=>{
 const {s,calls}=scene();s.theme='Stars';
 for(let i=0;i<100;i++){
  s.starTime=s.nextShootingStar;s.advanceShootingStar(0);const shot=s.shootingStar;
  assert.ok(shot.duration>=.22&&shot.duration<=.34);assert.ok(s.nextShootingStar-s.starTime>=22&&s.nextShootingStar-s.starTime<=55);
  assert.ok(shot.region.x+shot.region.width<=192||shot.region.x>=1008);
  for(const t of [0,.5,1]){const x=shot.x+shot.dx*t;assert.ok(x>=shot.region.x&&x<=shot.region.x+shot.region.width);}
  s.drawShootingStar();assert.ok(calls.some(c=>c[0]==='clip'));
  s.advanceShootingStar(shot.duration+.001);assert.equal(s.shootingStar,null);
 }
});
test('no meteor when paper fills viewport, and no hidden/pause clock advance',()=>{
 const {s,zone,document}=scene();zone.querySelector=()=>({getBoundingClientRect:()=>({left:0,right:1200})});s.starTime=s.nextShootingStar;s.advanceShootingStar(0);assert.equal(s.shootingStar,null);
 s.theme='Stars';s.paused=true;const at=s.starTime;s.frame(1000);s.frame(1040);assert.equal(s.starTime,at);s.paused=false;document.hidden=true;s.frame(100000);assert.equal(s.starTime,at);
});
