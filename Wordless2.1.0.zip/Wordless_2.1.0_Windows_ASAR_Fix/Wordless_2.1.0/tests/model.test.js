const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');const M=require('../src/model');
test('default Letter geometry',()=>assert.deepEqual(M.geometry({}),{size:'Letter',margin:1,zoom:1,mode:'pages',width:816,height:1056,inset:96,bodyHeight:864}));
test('layout clamps untrusted settings',()=>assert.deepEqual(M.layout({size:'__proto__',margin:20,zoom:-2,mode:'bad'}),{size:'Letter',margin:2,zoom:.5,mode:'pages'}));
test('NaN settings use defaults',()=>assert.equal(M.layout({margin:'bad'}).margin,1));
test('all supported sizes have positive content height',()=>{for(const size of Object.keys(M.sizes))assert.ok(M.geometry({size,margin:2}).bodyHeight>0);});
test('word count includes Unicode text',()=>assert.equal(M.words(' one\n two  café '),3));
test('empty document has one estimated page',()=>assert.equal(M.pageEstimate(0,{}),1));
test('estimate uses printable height',()=>assert.equal(M.pageEstimate(1729,{}),3));
test('pageless persists',()=>assert.equal(M.layout({mode:'pageless'}).mode,'pageless'));
test('renderer has no Node imports or network fetch',()=>{const s=fs.readFileSync('src/renderer.js','utf8');assert.doesNotMatch(s,/require\(|fetch\(|localStorage|innerHTML\s*=\s*e\.clipboardData/);});
test('one native contenteditable root',()=>{const s=fs.readFileSync('src/index.html','utf8');assert.equal((s.match(/contenteditable="true"/g)||[]).length,1);});
test('scene layer cannot receive pointer events',()=>assert.match(fs.readFileSync('src/style.css','utf8'),/#scene\{[^}]*pointer-events:none/));
test('main has sandbox and navigation guards',()=>{const s=fs.readFileSync('src/main.js','utf8');assert.match(s,/nodeIntegration:false/);assert.match(s,/sandbox:true/);assert.match(s,/senderFrame!==win.webContents.mainFrame/);assert.match(s,/will-navigate/);});

test('native legacy font markup survives sanitizer allowlist',()=>{const s=fs.readFileSync('src/main.js','utf8');assert.match(s,/font:\['color','face','size'\]/);});
